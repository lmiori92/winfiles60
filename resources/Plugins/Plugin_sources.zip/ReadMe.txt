## WinFile Plugins\\FileOpen directory ##

Questa cartella contiene i plugin, ovvero dei mini-programmi python adeguati che servono a gestire (aprire, visualizzare ecc...) alcuni tipi di file.
Il nome, esclusa la parte finale .py, determina l'estensione che il programma plugin � in grado di gestire. Non influisce il maiuscolo-minuscolo.
Da WinFile 1.04 i plugin possono essere collegati anche a pi� estenioni. Es: zip,jar,dta.py(c) -> Apre i file zip anche quelli rinominati in dta e jar.
N.B: il plugin deve essere programmato secondo le funzioni di WinFile. Per questo, se dovete fare cose particolari che superano i tutorial chiedete
a me per la documentazione ;).

Plugin predefiniti, presenti nella 1.05:

-arc (v0.2) - Apre e estrae file da archivi di backup arc
-zip,jar,dta (v1.1) - Apre file zip (e quindi anche jar e dta, zip rinominati): esplorazione e estrazione file
-vcf (v2.01) - Legge file vcf: visualizzazione in una lista di nome, numero e eventualmente immagine associata. Visualizza anche email e siti web
-skn (v1.2) - Legge e visualizza le propriet� di un file di tema (.skn), offrendo anche la possibilit� di rinominarlo a piacere
-sis (v0.3) - Legge file sis: esplorazione e estrazione file
-mbm (v1.0) - Legge e visualizza le immagini presenti in un file mbm (by Snake87)
-aif (v1.0) - Visualizza ed estrae le icone dei programmi (.aif)
-gif (v1.0b2) - Plugin ottimo con la possibilit� di gestire immagini animate gif! Estrazione fotogrammi e visualizzazione...
-ota (v1.0) - Plugin leggero e veloce per la lettura di immagini ota (loghi in b/n)

Opzionali oppure in fase beta/alpha/unstable: [forum download - zip with sources]

-html (v0.1) - Legge in modo molto semplice alcune caratteristiche di pagine html (by Giuppe)
-m3u (v0.1) - Legge in modo molto semplice playlist, elenca le canzoni con la durata e permette di fare un controllo di integrit�

WinFile Symbian OS S60 filemanager
�2008-2010 Memory