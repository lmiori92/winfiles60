_plugin_version_=2.01
_winfile_version_=1.04
_description_=u"V-Card plugin for WinFile by Memory\nIt reads a .vcf file and lists name and phone number\nVersion: %s"%(_plugin_version_)
#1.01: bug fix: it splits only the first ':' (field[options]: content) and it doesn't touch anymore the content
#2.00: parser completely rewritten; more accurated and a lot of bugs fixed; displays image of the contact
#2.01: added contact detail: names, numbers, emails and urls
class vcard:
    def __init__(s,filename):
        s.filename=filename
        s.file=open(filename,'rb')
        s.contacts_number=0
        s.contacts=[] #dictionaries of the entries
        s.raw_contacts=[] #real contact data block
    def load(s):
        error=0
        content=s.file.read().replace('\r\n','\n')
        s.contacts_number=content.count('BEGIN:VCARD')
        end=0
        for i in xrange(s.contacts_number):
            addr=content.find('BEGIN:VCARD',end)
            if addr==-1: break #vcard contact corrupted
            end=content.find('END:VCARD',addr)+10
            if end==-1: break
            s.raw_contacts.append(content[addr:end])
        for cnt in s.raw_contacts:
            ct={}
            c=cnt.splitlines()
            for ln in c:
                try:
                    field,value=ln.split(':',1)
                    ct[field]=value
                    #if debug: print field, value
                except ValueError: #multiline value or empty line
                    if ln:
                        sp=0
                        for id in ln:
                            if id=='\x20': #spaces
                                sp+=1
                            else:
                                break
                        ct[field]+=ln[sp:]
            s.contacts.append(ct)
    def search(s,i,field,n_o=0):
        if n_o: return filter(lambda x: field==(x.split(';',1)[0]),s.contacts[i])
        else: return filter(lambda x: x.find(field)>-1,s.contacts[i])
    def get(s,i,field):
        return map(lambda x: s.contacts[i][x],filter(lambda x: x.find(field)>-1,s.contacts[i]))
    def get_noptions(s,i,field):
        return map(lambda x: s.contacts[i][x],s.search(i,field,1))
    def close(s):
        s.file.close()
    def __del__(s):
        s.close()

class init_plugin:
    def __init__(s,module,filename):
        globals().update(module)
        try:
            user.direct_note(u"Lettura file vcf in corso...",u"V-Card")
            s.vcf=vcard(filename)
            s.vcf.load()
            s.vcf.close()
        except:
            user.note(u"Errore nell'apertura del file vcf",u"V-Card",-1)
            plugins.clean_module()
            return
        ListBox.reset()
        ListBox.left_cb=lambda: plugins.stop_module(0)
        ListBox.sel_cb=s.details
        ListBox.no_data=u"L'archivio V-Card (vcf) non contiene alcun contatto o il formato � danneggiato o non supportato."
        ui.menu.menu([(u"Dettagli Contatto [OK]",[s.details]),(u"Plugin Info",[s.about])]+main.exit_menu)
        s.set_list()
    
    def set_list(s,pos=0):
        ListBox.elements=[]
        ListBox.selected=[]
        for contact in xrange(s.vcf.contacts_number):
            try: number=' ; '.join(s.vcf.get(contact,'TEL'))
            except: number=u"Nessun numero"
            try: name=s.vcf.get_noptions(contact,'N')[0].replace(";"," ")
            except:
                try: name=s.vcf.get_noptions(contact,'FN')[0].replace(";"," ")
                except: name=u"Nessun nome"
            try:
                ph=s.vcf.get(contact,'PHOTO')[0].decode('base64')
                open('D:\\vcf_plugin_temp','wb').write(ph)
                i=[Image.open('D:\\vcf_plugin_temp').resize((32,32),keepaspect=1)]
                try: os.remove('D:\\vcf_plugin_temp')
                except: pass
            except:
                i=[]
            if name[0]==' ':
                name=name[1:]
            try: ListBox.elements.append(LType(to_unicode(name),to_unicode(number),u"Contatti presenti in archivio",icon=i))
            except: ListBox.elements.append(LType(u"Errore contatto"))
        ListBox.select_item(pos)

    def details(s):
        cnt=ListBox.current()
        text=u"%s\n%s\n%s\n%s"%(ListBox.elements[cnt].name,ListBox.elements[cnt].undername,u'-'.join(map(to_unicode,s.vcf.get_noptions(cnt,'EMAIL'))),u'-'.join(map(to_unicode,s.vcf.get_noptions(cnt,'URL'))))
        user.note(text,u"Contatto",-1)

    def about(s):
        user.note(_description_,u"V-Card Plugin",-1)