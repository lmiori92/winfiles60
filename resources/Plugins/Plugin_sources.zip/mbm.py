#Multi-Bitmap (*.mbm) plugin for WinFile
#It reads simply mbm files. It reads only an image and display it.

_plugin_version_=1.0
_winfile_version_=1.04
_description_=u'Plugin di WinFile che serve a visualizzare tutte le immagini contenute in un file .mbm (Multi-Bitmap).'

import os

############################
#Classe per la gestione dei file mbm
############################
#Created by Shrim
#Edit by Snake87

class mbmfile:
 def __init__(s):
  import graphics,struct#,os
  s._o,s._g,s._unpack,s._pack=os,graphics.Image,struct.unpack,struct.pack
  s.__set_var__()

 def __set_var__(s):
  s._index=0
  s._maxindex=0
  s._b=None
  s._path=None
  s._tmpfile=None

 def __image__(s,path,index):
  file=open(path)
  file.seek(16)
  file.seek(s._unpack('i',file.read(4))[0])
  s._maxindex=s._unpack('i',file.read(4))[0]
  if index>=s._maxindex:
   index=0
  s._index=index
  file.seek(index*4,1)
  position=s._unpack('i',file.read(4))[0]
  file.seek(position)
  dlina=s._unpack('i',file.read(4))[0]
  file.seek(4,1)
  x,y=s._unpack('ii',file.read(8))
  file.seek(8,1)
  b=s._unpack('i',file.read(4))[0]
  if b>23: s._b='RGB'
  elif b>14: s._b='RGB16'
  elif b>11: s._b='RGB12'
  elif b>7: s._b='L'
  else: s._b='1'
  file.seek(position)
  tempfile=open(s._tmpfile,'w')
  tempfile.write('\x37\x00\x00\x10\x42\x00\x00\x10\x00\x00\x00\x00\x39\x64\x39\x47'+s._pack('i',dlina+20)+file.read(dlina)+'\x01\x00\x00\x00\x14\x00\x00\x00')
  file.close()
  tempfile.close()
  img=s._g.new((x,y),s._b)
  try:
   img.load(s._tmpfile)
  except:
   s._o.remove(s._tmpfile)
   raise IOError('image not load')
  s._o.remove(s._tmpfile)
  return img

 def ismbm(s,path):
  file=open(path)
  c=True
  if file.read(16)!='\x37\x00\x00\x10\x42\x00\x00\x10\x00\x00\x00\x00\x39\x64\x39\x47':
    c=False
  file.close()
  return c

 def open(s,path,tmp='D:\\Temp.mbm'):
  s.__set_var__()
  s._tmpfile=tmp
  s._path=path
  if not s._o.path.exists(path):
   raise IOError('file not exists')
  if not s.ismbm(path):
   raise IOError('file not mbm')
  return s.__image__(path,0)

 def next(s):
   return s.__image__(s._path,s._index+1)

 def previous(s):
  if s._index==0:
   s._index=s._maxindex
  return s.__image__(s._path,s._index-1)

 def image(s,index):
  return s.__image__(s._path,index-1)

 def current(s):
  return s._index+1

 def total(s):
  return s._maxindex

 def bit(s):
  return s._b
############################

mbmf=mbmfile()
del mbmfile


class init_plugin:
  def __init__(s,module,filename):
    globals().update(module)
    s.plugin_name=u"Multi-Bitmap Plugin"
    s.filename=filename
    s.content_of_dir=[]
    s.temp=u"D:\\MBM\\"
    s.data_file=directory.data_dir+"\\mbm_plugin.dat"
    s.comp_type=1
    s.extractdir=os.path.splitext(filename)[0]+"\\"
    if not mbmf.ismbm(filename):
      user.note(u"File MBM danneggiato o non supportato!",s.plugin_name)
      plugins.plugin,plugins.active_plugin_name=None,None
      return
    s.remember(0)
    mbmf.open(filename)
    if os.path.exists(s.temp):
      gestione_file.removedir(s.temp)
    os.makedirs(s.temp)
    i=1
    while i<mbmf.total()+1:
      file=s.file_name(i)
      path=os.path.join(s.temp,file)
      s.content_of_dir.append((path,file,1))
      i+=1
    s.old_cbs=[ListBox.mode_cb,ListBox.sel_cb,ListBox.right_cb,ListBox.left_cb]
    ListBox.cbind()
    s.keys()
    ListBox.mode_cb=s.keys
    ListBox.left_cb=s.back_handler
    ListBox.right_cb=lambda:None
    ListBox.sel_cb=s.go
    ListBox.no_data=u"Il file MBM non contiene nessuna immagine oppure � danneggiato"
    ListBox.position,ListBox.page=0,0
    ui.menu.menu([(u"Estrai...",[(u"File singolo [2]",s.extract_one),(u"Tutto [8]",s.extract)]),(u"Tipo compressione [6]",[s.opzione_compressione]),(u"Dettagli Multi-Bitmap [5]",[s.info]),(u"Plugin Info",[s.about])]+main.exit_menu)
    s.set_list()

  def file_name(s,num):
    st=unicode(str(num))
    if num<10:
      st="0"+st
    if num<100:
      st="0"+st
    del num
    return u"image"+st+u".bmp"

  def about(s):
    user.note(s.plugin_name+u" by Snake87\nVisualizza tutte le immagini presenti nei file MBM\nVersion: "+to_unicode(str(_plugin_version_)),s.plugin_name,-1)

  def info(s):
    d=time.localtime(os.path.getmtime(s.filename))
    d=u"%i/%i/%i %.2i:%.2i:%.2i"%(d[2],d[1],d[0],d[3],d[4],d[5])
    t=u'Immagini: %i\nDimensione: %s\n%s'%(mbmf.total(),dataformatter.sizetostr(os.path.getsize(s.filename)),d)
    user.note(t,to_unicode(os.path.split(s.filename)[1]),timeout=-1)

  def set_list(s,position=0):
    bakland=ui.landscape
    ui.change_screen_mode(0)
    d=progress_dialog(u"Caricamento file MBM in corso...",to_unicode(s.plugin_name+" - "+"0%"),max=len(s.content_of_dir))
    d.draw()
    ListBox.elements=[]
    ListBox.selected=[]
    titolo=os.path.split(s.filename)[1]
    titolo=to_unicode(titolo)
    i=1
    for path,name,type in s.content_of_dir:
      ListBox.elements.append(LType(name=to_unicode(name),undername=None,title=titolo,type=0,hid=0,icon=ext_util.search_path(name)[1]))
      d.set_title(to_unicode(s.plugin_name+" - "+str(i*100/mbmf.total()))+u"%")
      d.forward()
      d.draw()
      i+=1
    d.close()
    del d
    ui.change_screen_mode(bakland)
    if len(ListBox.elements):
      ListBox.select_item(position)
    else:
      ListBox.redrawlist()

  def get_file(s):
    return s.content_of_dir[ListBox.current()][0]

  def get_name(s):
    return s.content_of_dir[ListBox.current()][1]

  def create_image(s):
    if not os.path.exists(s.temp+s.file_name(ListBox.current()+1)):
      s.imgtmp=mbmf.image(ListBox.current()+1)
      s.imgtmp.save(s.temp+s.file_name(ListBox.current()+1)[:-4]+u".png")
      del s.imgtmp
      os.rename(s.temp+s.file_name(ListBox.current()+1)[:-4]+u".png",s.temp+s.file_name(ListBox.current()+1))

  def go(s):
    if len(s.content_of_dir)>0:
      s.create_image()

      class mod_viewer(mini_viewer):

        def next(self):
          if ListBox.current()<len(s.content_of_dir)-1:
            ListBox.position+=1
          else:
            ListBox.position=0
            ListBox.page=0
          s.create_image()
          self.file=s.get_file()
          self.name=s.get_name()
          e32.ao_sleep(0,self.carica_immagine)
          self.caricato=0
          self.create_image()
          self.redraw_img((),0)

        def previous(self):
          if ListBox.current()>0:
            ListBox.position-=1
          else:
            ListBox.position=len(s.content_of_dir)-1
          s.create_image()
          self.file=s.get_file()
          self.name=s.get_name()
          e32.ao_sleep(0,self.carica_immagine)
          self.caricato=0
          self.create_image()
          self.redraw_img((),0)

      
      mod_viewer(s.get_file(),s.restore_plugin_UI)

  def back_handler(s):
    if os.path.exists(s.temp):
      if len(os.listdir(s.temp))==0:
        s.tempo1=1
      else:
        s.tempo1=len(os.listdir(s.temp))
      bakland=ui.landscape
      ui.change_screen_mode(0)
      d=progress_dialog(u"Rimozione file temporanei in corso",s.plugin_name,max=s.tempo1)
      del s.tempo1
      d.draw()
      try:
        for c in os.listdir(s.temp):
          os.remove(s.temp+c)
          d.set_title(to_unicode(c))
          d.forward()
          d.draw()
        os.removedirs(s.temp)
        d.set_title(s.temp)
        d.forward()
        d.draw()
      except Exception,e:
        print str(e)
      d.close()
      ui.change_screen_mode(bakland)
    plugins.stop_module(1,s.restore)

  def keys(s):
    ui.bind(EKey5,s.info)
    ui.bind(EKey8,s.extract)
    ui.bind(EKey2,s.extract_one)
    ui.bind(EKey6,s.opzione_compressione)

  def opzione_compressione(s):
    s.comp_type=user.query(u"Scegliere il tipo di compressione per l'immagine.",s.plugin_name,left=u"PNG",right=u"JPG")
    s.remember(1)

  def remember(s,t):
    if t:
      try:
        open(s.data_file,'wb').write(chr(s.comp_type))
      except:
        pass
    else:
      try:
        s.comp_type=ord(open(s.data_file).read(1))
      except:
        pass

  def extract_one(s):
    if not user.query(u"Estrarre il file %s nella cartella %s"%(to_unicode(os.path.basename(s.get_file()))[:-4],to_unicode(s.extractdir)),s.plugin_name,left=u"Estrai"):
      return
    import sysinfo
    #molto approssimativa
    if os.path.getsize(s.filename)/mbmf.total()>sysinfo.free_drivespace()[s.filename[0:2].capitalize()]:
      user.note(u"Spazio su disco insufficiente per continuare!\nEliminare qualche dato e riprovare",s.plugin_name)
      return
    d=progress_dialog(u"Estrazione immagine in corso...",u"Creazione cartella",max=1)
    d.draw()
    d.forward()
    if s.comp_type:
      d.set_title(to_unicode(os.path.basename(s.get_file()))[:-4]+".png")
    else:
      d.set_title(to_unicode(os.path.basename(s.get_file()))[:-4]+".jpg")
    d.draw()
    s.extract_file(ListBox.current()+1)
    d.close()
    user.note(u"Estrazione del file %s completata!"%(to_unicode(os.path.basename(s.get_file()))[:-4]),s.plugin_name)

  def extract(s):
    if not user.query(u"Estrarre il contenuto del file MBM nella cartella %s"%(to_unicode(s.extractdir)),s.plugin_name,left=u"Estrai"):
      return
    import sysinfo
    if os.path.getsize(s.filename)>sysinfo.free_drivespace()[s.filename[0:2].capitalize()]:
      user.note(u"Spazio su disco insufficiente per continuare!\nEliminare qualche dato e riprovare",s.plugin_name)
      return
    bakland=ui.landscape
    ui.change_screen_mode(0)
    d=progress_dialog(u"Estrazione immagini in corso...",u"Creazione cartella",max=mbmf.total())
    i=1
    d.draw()
    while i<mbmf.total()+1:
      d.forward()
      if s.comp_type:
        d.set_title(to_unicode(s.file_name(i)[:-4]+".png"))
      else:
        d.set_title(to_unicode(s.file_name(i)[:-4]+".jpg"))
      d.draw()
      s.extract_file(i)
      i+=1
    d.close()
    ui.change_screen_mode(bakland)
    user.note(u"Estrazione completata!",s.plugin_name)

  def extract_file(s,number):
    if not os.path.exists(s.extractdir):
      os.makedirs(s.extractdir)
    s.tempoimg=mbmf.image(number)
    if s.comp_type:
      s.tempoimg.save(s.extractdir+s.file_name(number)[:-3]+u"png")
    else:
      s.tempoimg.save(s.extractdir+s.file_name(number)[:-3]+u"jpg")

  def restore(s):
    ListBox.mode_cb,ListBox.sel_cb,ListBox.right_cb,ListBox.left_cb=s.old_cbs

  def restore_plugin_UI(s,to_elem=None,ui_state=None):
    if ui_state:
      ui.set_state(ui_state)
    if ui.mode_callback!=None: ui.mode_callback()
    ListBox.select_item(ListBox.current())