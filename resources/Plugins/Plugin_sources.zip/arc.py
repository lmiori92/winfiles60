_plugin_version_=0.2
_winfile_version_=1.03 #Non usa funzioni inserite nelle successive versioni, quindi...
_description_=u"Arc Plugin by Memory\nIt reads the .arc backup files!\nVersion: %s"%str(_plugin_version_)
_plugin_name_=u"Arc Backup Plugin"

EXTRACTION_BUFFER=10240 #10 KB estratti, decompressi e sritti. Si potrebbe anche aumentare per aumentare la velocit�

#####
#arc_file.py 0.2 by Memory (22/06/09)
#####
#This modules manages .arc files: backup files created by Symbian OS (Memory Tools) 
#Questa libreria gestisce file .arc: file di backup creati dal sistema operativo Symbian (app. Memoria)

#ARC FILE STRUCTURE (discovered by me)

#NOTE: data blocks (file content) are compressed with zlib. So we have to decompress them first, before to use.
#START first byte->always 00??
#4 byte after -> total files
#10 byte after ->First file name lenght
#file name end->10byte after->4 byte real file size->4byte compressed file size
#This is repeated n times (n is the total files number) -> Next file is after the data block (it starts with the lenght of filename)
#In the last 6-8 bytes of the arc there is like a signature (in N70 is RM8405, rm84 is the model and the other things I don't know)
#END
#Some bytes are maybe not used or they represent other data (not so important, maybe creation date or attributes)

import struct,zlib,os

class arc:
    def __init__(s,filename):
        s.filelist=[]
        s.data={} #Diz: Nome file : [posizione assoluta dati,lunghezza dati,dimensione scompressa] -> Filename : [data absolute position, data lenght (compressed), file size (uncompressed)]
        s.numfiles=0
        s.real_size=0
        s.loaded=0
        s.model=u''
        s.filename=filename
        s.file=open(filename,'rb')
        s.file.seek(0,2)
        s.filesize=s.file.tell()
    def load(s):
        if s.loaded:
            return
        s.file.seek(1)
        s.numfiles=struct.unpack('L',s.file.read(4))[0]
        s.file.seek(10)
        i=0
        while 1:
            len_uni=ord(s.file.read(1))
            fn=s.file.read(len_uni).decode('UTF-16LE')
            s.filelist.append(fn)
            s.file.seek(10,1)
            filesize=struct.unpack('L',s.file.read(4))[0]
            len_data=struct.unpack('L',s.file.read(4))[0]
            s.data[fn]=[s.file.tell(),len_data,filesize]
            s.real_size+=filesize
            s.file.seek(len_data,1)
            i+=1
            if i==s.numfiles: break
        s.model=s.file.read(5)
        s.loaded=1
    # def get(s,n):
        # s.file.seek(s.data[n][0])
        # return s.file.read(s.data[n][1]).decode('zlib')
    def close(s):
        s.file.close()
       # print 'File closed!'
    def __del__(s):
       # print 'Cleaning up...'
        s.close()

class init_plugin:
    def __init__(s,module,filename):
        globals().update(module)
        s.dir=u"" #Stringa vuota = directory radice
        s.content_of_dir=[]
        s.archive_path=filename
        s.archive_name=os.path.basename(filename)
        s.extract_dir=os.path.join(os.path.split(filename)[0],os.path.basename(filename)+"_extract\\")
        s.arc=arc(filename)
        s.arc.load()
        s.scan()
        ListBox.reset() #Reimposta solo i tasti necessari per controllare la listbox
        #ListBox.mode_cb=s.keys#lambda:None
        ListBox.sel_cb=s.go
        ListBox.right_cb=s.go
        #ListBox.position,ListBox.page=0,0
        ListBox.left_cb=s.back_handler
        #plugins.plugin_end_cb=plugins.clean_module
        ListBox.no_data=u"Il backup non contiene alcun file o cartella oppure � danneggiato."
        s.keys()
        ui.menu.menu(main.select_menu+[(u"Estrai...",[(u"Singolo o selez. [2]",s.unpack),(u"Tutto [8]",s.unpack_all)]),
                    (u"Dettagli backup [5]",[s.arc_details]),
                    (u"Plugin Info",[s.about])]+main.exit_menu)
        s.set_list()

    def keys(s):
        ui.bind(EKey5,s.arc_details)
        ui.bind(EKey8,s.unpack_all)
        ui.bind(EKey2,s.unpack)

    def about(s):
        user.note(_description_,_plugin_name_,-1)

    def arc_details(s):
        text=u"Files: %i\nDimensione: %s\nDim. max scompressa: %s\nModello: %s"%(s.arc.numfiles,dataformatter.sizetostr(s.arc.filesize),dataformatter.sizetostr(s.arc.real_size),s.arc.model)
        user.note(text,u"Dettagli Backup",-1)
        del text

    def back_handler(s):
        if not s.dir:
            s.arc.close()
            plugins.stop_module(1)#,s.restore)
        else:
            s.back()

    def set_list(s,position=0):
            ListBox.elements=[]
            ListBox.selected=[]
            d=u"%s\\%s"%(s.archive_name,s.dir)#.replace("/","\\")
            ListBox.no_data=u"La cartella %s non contiene elementi"%d
            dir_ico=[grafica.cartella_img,grafica.cartella_mask]
            for path,name,type,size in s.content_of_dir:
                try:
                    if type==1:
                        if settings.get_size_on_canvas: u=dataformatter.sizetostr(size)
                        else: u=None
                        ListBox.elements.append(LType(name,u,d,icon=ext_util.search_path(name)[1]))
                    else:
                        ListBox.elements.append(LType(name,title=d,icon=dir_ico))
                except:
                    ListBox.elements.append(LType(name=u"Errore visualizzazione",title=u"Errore elemento"))
            ListBox.select_item(position)

    def get_file(s,se=0):
        if se:
            return map(lambda i: s.content_of_dir[i][0], ListBox.selected)
        else:
            return s.content_of_dir[ListBox.current()][0]

    def get_file_info(s,name):
        return s.arc.data[name]

    def is_file(s,n):
        if n in s.arc.filelist:
            return True
        return False

    def scan(s):
        d,f=[],[]
        s.content_of_dir=[]
        for file in s.listdir(s.dir,s.arc.filelist):
            path=os.path.join(s.dir,file)
            if s.is_file(path):
                f.append((path,file,1,s.arc.data[path][2]))
            else:
                d.append((path+u"\\",file,0,0))
        s.content_of_dir=d+f
        del d,f

    def go(s):
        if s.content_of_dir:
            fn=s.get_file()
            if not s.is_file(fn):
                s.dir=fn
                s.scan()
                s.set_list()
            else:
                s.unpack()

    def back(s):
        if s.dir.count(u'\\')<=1:
            try: w=s.dir.strip(u'\\')
            except: w=0
            s.dir=u''
        else:
            x=s.dir.split(u'\\')
            x=x[0:len(x)-1]
            w=x[-1]
            x=x[0:len(x)-2]
            s.dir=s.dir[:-(len(w)+1)]
        s.scan()
        s.set_list(w)

    def normpath(s,x):
        if x[-1] in [u'\\',u'/']:
            return x
        else:
            return x + u'\\'

    def listdir(s,dire,list):
        tmp=[]
        if dire in ["","\\","/"]:
            for i in list:
                path=i.split("\\")[0]
                if not path in tmp:
                    tmp.append(path)
        else:
            dire=s.normpath(dire)
            for i in list:
                try: value=(i.split(dire)[1]).split("\\")
                except: continue
                t=value[0]
                if not t in tmp: tmp.append(t)
        tmp=s.alfabetico(tmp)
        return tmp

    def alfabetico(s,lista):
        _index,_lista_lower,_lista_lower_orig=[],[],[]
        _lista_orig=lista
        _lista_lower=map(lambda x: x.lower(),lista)
        _lista_lower_orig=_lista_lower[:]
        _lista_lower.sort()
        _index=map(_lista_lower_orig.index,_lista_lower)
        return map(lambda i: _lista_orig[i],_index)

    def lista(s,path,list):
        for child in s.listdir(path,s.arc.filelist):
            tpath=os.path.join(path,child)
            if s.is_file(tpath):
                list.append(tpath)
            else:
                s.lista(tpath,list)

    def unpack(s):
        #Wrapper della funzione unpack_all con una query
        title=u"Estrazione"
        key=u"Estrai"
        name=s.get_file()
        tmp=[]
        if ListBox.selected:
            if user.query(u"Estrarre gli elementi selezionati?",title,left=key):
                for i in s.get_file(1):
                    if s.is_file(i):
                        tmp.append(i)
                    else:
                        s.lista(i,tmp)
                s.unpack_all(tmp)
        else:
            if s.is_file(name):
                if user.query(u"Estrarre il file %s?"%os.path.basename(name),title,left=key):
                    s.unpack_all([name])
            else:
                s.lista(name,tmp)
                if user.query(u"Estrarre tutti gli elementi presenti (%i) nella cartella?"%len(tmp),title,left=key):
                    s.unpack_all(tmp)

    def unpack_all(s,list=None):
        #Estrazione di pi� file dati in lista o caricati direttamente da tutti i file dell'arc
        #Copia a piccole parti (EXTRACTION_BUFFER) per non caricare l'intero file in ram (rischioso e non stabile)
        import zlib
        s.running=1
        total_written=0
        if not (list in [[],None]):
            num=len(list)
            files=list
            tsz=0
            for i in list:
                tsz+=s.arc.data[i][2]
        else:
            num=s.arc.numfiles
            files=s.arc.filelist
            tsz=s.arc.real_size
        def abort():
            s.running=0
        d=progress_dialog(u"Inizializzazione\n\n",u"Estrazione elementi",max=tsz,break_cb=abort)
        d.draw()
        for i in xrange(0,num):
            bytes_written=0
            name=files[i]
            pos,lng,dim=s.get_file_info(name)
            d.to_draw[-2]=name
            d.to_draw[-1]=u"(%i di %i)"%(i+1,num)
            d.draw()
            name=name.replace('C:\\',s.extract_dir)
            try: os.makedirs(os.path.split(name)[0])
            except: pass
            try:
                s.arc.file.seek(pos)
                zlib_class = zlib.decompressobj()
                b=open(ur(name),'wb',EXTRACTION_BUFFER)
                while (bytes_written < dim) and (s.running):
                    temp_bytes = s.arc.file.read(EXTRACTION_BUFFER)
                    temp_bytes = zlib_class.decompress(temp_bytes)
                    bytes_written += len(temp_bytes)
                    b.write(temp_bytes)
                    d.update_state(total_written+bytes_written)
                    d.draw()
                    e32.ao_yield()
                b.close()
            except: pass# Exception,e:
                # print str(e)
                # error=1
            total_written+=dim
            if not s.running:
                try: os.remove(name)
                except: pass
                break
            #e32.ao_yield()
        d.close()
        try: b.close() #Se ad esempio � avvenuto un errore e il file non si � chiuso correttamente
        except: pass
