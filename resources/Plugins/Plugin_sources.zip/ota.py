'''WINFILE PLUGIN'''
#OTA (*.ota) plugin for WinFile
#It reads simply ota image files and return it as an image

_plugin_version_=1.0
_winfile_version_=1.04
_description_=u'Plugin di WinFile che serve a visualizzare le immagini .ota.'

import os

############################
#Classe per la gestione dei file ota
############################
#Created by Snake87
#http:\\Snake87r.netsons.org
#Legge e scrive i file ota (loghi operatore dei vecchi terminali nokia come il 3210-3310-3330)

import graphics

class Otafile:
  def __init__(s):
    s.W,s.H=72,28

  def isota(s,fn):
    f=open(fn)
    e=f.read(4)=='\x00\x48\x1c\x01'
    f.seek(0,2)
    c=f.tell()==256
    f.close()
    return e and c

  def dtb(s,n):
    e=''
    while n>0:
      e=str(n%2)+e
      n/=2
    while 8-len(e)>0:
      e='0'+e
    return e

  def btd(s,n):
    e,b,num=0,0,str(n)
    a=len(num)-1
    while a>=0:
      e+=pow(2,b)*int(num[a])
      b+=1
      a-=1
    return e

  def open(s,fn):
    f=open(fn)
    f.read(4)
    s.im=graphics.Image.new((s.W,s.H),'L')
    for y in range(s.H):
      b,l=f.read(9),''
      for a in b:
        l+=s.dtb(ord(a))
      for x in range(s.W):
        if int(l[x]):
          s.im.point((x,y),0)
    f.close()
    return s.im

  def save(s,img,fn):
    if not(img.size[0]==s.W and img.size[1]==s.H):
      return 0
    else:
      try:
        f=open(fn,'wb')
        f.write('\x00\x48\x1c\x01')
        t=''
        for y in range(s.H):
          for x in range(s.W):
            if img.getpixel((x,y))[0]==(0,0,0):
              t+='1'
            else:
              t+='0'
            if len(t)==8:
              f.write(chr(s.btd(t)))
              t=''
        f.close()
      except:
        f.close()
        try:
          os.remove(fn)
        except:
          pass
        return 0
      return 1
############################

ota=Otafile()
del Otafile


class init_plugin:
  def __init__(s,module,filename):
    globals().update(module)
    s.plugin_name=u"OTA Plugin"
    s.temp=u"D:\\OTA\\"
    if not ota.isota(filename):
      user.note(u"File OTA danneggiato o non supportato!",s.plugin_name)
      plugins.clean_module()
      return
    if os.path.exists(s.temp):
      gestione_file.removedir(s.temp)
    os.makedirs(s.temp)
    img=ota.open(filename)
    newname=s.temp+os.path.split(filename)[1][:-3]+u'png'
    img.save(newname)
    del img
    os.rename(newname,newname[:-3]+u'ota')
    mini_viewer(newname[:-3]+u'ota',s.restore_plugin_UI)
    gestione_file.removedir(s.temp)
    plugins.clean_module()

  def restore_plugin_UI(s,to_elem=None,ui_state=None):
    if ui_state:
      ui.set_state(ui_state)
    if ui.mode_callback!=None: ui.mode_callback()