'''WINFILE PLUGIN'''
#GIF (*.gif) plugin for WinFile
#It reads simply gif files. It reads only an image and display it.

_plugin_version_=1.0
_winfile_version_=1.04
_description_=u'Plugin di WinFile che serve a visualizzare tutte le immagini contenute in un file .gif.'

import miso,os

############################
#Classe per la gestione dei file gif
############################
#Created by Snake87
#http://Snake87r.netsons.org
#Extract the n frame from the gif and return it as an Image object

import graphics#, os

def _i16(c):
  return ord(c[0])+(ord(c[1])<<8)

class giffile:
  def __init__(self):
    self.index = 0
    self.pos = []
    self.info = {}

  def isgif(self,filename):
    f = open(filename)
    a = f.read(6)
    f.close()
    del f
    return a in ["GIF87a","GIF89a"]

  def delays(s):
    frame_header='\x21\xf9\x04' #byte fissi
    dl=[]
    p=0
    while 1:
        fp=s.file2.find(frame_header,p)
        if fp==-1:
            break
        else:
            p=fp+len(frame_header)
            try:
                delay=_i16(s.file2[p+1:p+3])
                #is_transparent=ord(s.file2[p])
                dl.append(delay)
            except:
                dl.append(0)
    return dl

  def frame_info(s):
    frame_header='\x21\xf9\x04' #byte fissi
    dl=[]
    p=0
    while 1:
        fp=s.file2.find(frame_header,p)
        if fp==-1:
            break
        else:
            p=fp+len(frame_header)
            try:
                delay=_i16(s.file2[p+1:p+3])
                #is_transparent=ord(s.file2[p])
                dl.append(delay)
            except:
                dl.append(0)
    return dl

  def repeat_anim(s):
    i=s.file2.find('NETSCAPE2.0')
    t=s.file2[i+13:i+14]
    if t=='\xff\xff':
        return 1
    return 0

  def isanimated(self,filename):
    f = open(filename)
    stream = f.read()
    f.close()
    del f
    if stream.find('\x4e\x45\x54\x53\x43\x41\x50\x45')!=-1:
      stream= None
      del stream
      return True
    else:
      stream=None
      del stream
      return False

  def open(self,filename,tempf=u"D:\\Temp.gif"):
    self.filename = filename
    self.tmpfile = tempf
    self.pos = []
    self.header = None
    self.fp = open(filename)
    self.file = self.fp.read()
    self.file2 = self.file
    self.fp.close()
    del self.fp
    s=self.file[:13]
    self.file=self.file[13:]
    self.info["version"] = s[:6]
    self.info["size"] = _i16(s[6:]),_i16(s[8:])
    flags = ord(s[10])
    bits =(flags & 7) + 1
    if flags & 128:
      self.info["background"] = ord(s[11])
      self.info["aspect_ratio"]=ord(s[12])
      self.file=self.file[3<<bits:]
      self.header_end = 13+(3<<bits)
    del flags
    del bits
    s=1
    while s!=0:
      s = self.file.find('\x00\x21\xF9\x04')+1
      self.file=self.file[s:]
      if s!=0:
        if len(self.pos)==0:
          spos=s+self.header_end
        else:
          spos=s+self.pos[len(self.pos)-1]
        self.pos.append(spos)
      else:
        break
    del spos
    del s
    self.last_end = len(self.file)-1+self.pos[len(self.pos)-1]
    self.file=None
#    return self.image(1)

  def total(self):
    return len(self.pos)

  def current(self):
    return self.index+1

  def image(self,num,name=None):
    if num<1:
      num=1
    if num>len(self.pos):
      num=len(self.pos)
    self.index=num-1
    #Legge Header
#    f=open(self.filename)
#    self.file=f.read()
#    f.close()
#    del f
    if self.header==None:
      self.header=self.file2[:self.header_end]

    #Scrive il file temporaneo
    if num<len(self.pos):
      self.finale=-(self.last_end-self.pos[num])-1
    else:
      self.finale=-1
    self.img=self.file2[self.pos[num-1]:self.finale]
    if name==None:
      f=open(self.tmpfile,'wb')
    else:
      f=open(name,'wb')
    f.write(self.header+self.img+'\x3b')
    f.close()
    del f
#    self.file=None

    if name==None:
      self.img=graphics.Image.open(self.tmpfile)
      os.remove(self.tmpfile)
      return self.img

  def close(self):
    self.img=None
    self.file2 = None

  def next(self):
    if index==len(self.pos)-1:
      index=0
    else:
      index+=1
    return self.image(index+1)

  def previous(self):
    if index==0:
      index=len(self.pos)-1
    else:
      index-=1
    return self.image(index+1)
############################

giff=giffile()
del giffile


class init_plugin:
  def __init__(s,module,filename):
    globals().update(module)
    s.plugin_name=u"GIF Plugin"
    s.filename=filename
    s.content_of_dir=[]
    s.temp=u"D:\\GIF\\"
    s.extractdir=os.path.splitext(filename)[0]+"\\"
    if not giff.isgif(filename):
      user.note(u"File GIF danneggiato o non supportato!",s.plugin_name)
      plugins.plugin,plugins.active_plugin_name=None,None
      return
    if not giff.isanimated(filename):
      user.note(u"File GIF non animato",s.plugin_name)
      mini_viewer(filename,s.restore_plugin_UI2)
      return
    giff.open(filename)
    #s.frame_delays=giff.delays()
    if os.path.exists(s.temp):
      gestione_file.removedir(s.temp)
    os.makedirs(s.temp)
    i=1
    while i<giff.total()+1:
      file=s.file_name(i)
      path=os.path.join(s.temp,file)
      s.content_of_dir.append((path,file,1))
      i+=1
    s.old_cbs=[ListBox.mode_cb,ListBox.sel_cb,ListBox.right_cb,ListBox.left_cb]
    ListBox.cbind()
    s.keys()
    ui.unbind(EKey0)
    ListBox.mode_cb=s.keys
    ListBox.left_cb=s.back_handler
    ListBox.right_cb=lambda:None
    ListBox.sel_cb=s.go
    ListBox.no_data=u"Il file GIF non contiene nessuna immagine oppure � danneggiato"
    ListBox.position,ListBox.page=0,0
    ui.menu.menu([(u"Estrai...",[(u"File singolo [2]",s.extract_one),(u"Tutto [8]",s.extract)]),(u"Dettagli GIF [5]",[s.info]),(u"Plugin Info",[s.about])]+main.exit_menu)
    s.set_list()
    #(u"Animazione [test]",[s.animate]),

  # def animate(s):
    # i=0
    # while i<giff.total()+1:
        # img=giff.image(i)
        # ui.canvas.blit(img)
        # e32.ao_sleep(s.frame_delays[i]/100)
        # i+=1
  def restore_plugin_UI2(s,to_elem=None,ui_state=None):
    if ui_state:
      ui.set_state(ui_state)
    if ui.mode_callback!=None: ui.mode_callback()

  def file_name(s,num):
    st=unicode(str(num))
    if num<10:
      st="0"+st
    if num<100:
      st="0"+st
    del num
    return u"image"+st+u".gif"

  def about(s):
    user.note(s.plugin_name+u" by Snake87\nVisualizza tutte le immagini presenti nei file GIF\nVersion: "+to_unicode(str(_plugin_version_))+u"beta2",s.plugin_name,-1)

  def info(s):
    d=time.localtime(os.path.getmtime(s.filename))
    d=u"%i/%i/%i %.2i:%.2i:%.2i"%(d[2],d[1],d[0],d[3],d[4],d[5])
    t=u'Immagini: %i\nVersione: %s\nDimensione: %s\n%s'%(giff.total(),giff.info["version"],dataformatter.sizetostr(os.path.getsize(s.filename)),d)
    user.note(t,to_unicode(os.path.split(s.filename)[1]),timeout=-1)

  def set_list(s,position=0):
    bakland=ui.landscape
    ui.change_screen_mode(0)
    d=progress_dialog(u"Caricamento file GIF in corso...",to_unicode(s.plugin_name+" - "+"0%"),max=len(s.content_of_dir))
    d.draw()
    ListBox.elements=[]
    ListBox.selected=[]
    titolo=os.path.split(s.filename)[1]
    titolo=to_unicode(titolo)
    i=1
    for path,name,type in s.content_of_dir:
      ListBox.elements.append(LType(name=to_unicode(name),undername=None,title=titolo,type=0,hid=0,icon=ext_util.search_path(name)[1]))
      d.set_title(to_unicode(s.plugin_name+" - "+str(i*100/giff.total()))+u"%")
      d.forward()
      d.draw()
      i+=1
    d.close()
    del d
    ui.change_screen_mode(bakland)
    if len(ListBox.elements):
      ListBox.select_item(position)
    else:
      ListBox.redrawlist()

  def get_file(s):
    return s.content_of_dir[ListBox.current()][0]

  def get_name(s):
    return s.content_of_dir[ListBox.current()][1]

  def create_image(s):
    if not os.path.exists(s.temp+s.file_name(ListBox.current()+1)):
      giff.image(ListBox.current()+1,s.temp+s.file_name(ListBox.current()+1))

  def go(s):
    if len(s.content_of_dir)>0:
      s.create_image()

      class mod_viewer(mini_viewer):

        def next(self):
          if ListBox.current()<len(s.content_of_dir)-1:
            ListBox.position+=1
          else:
            ListBox.position=0
            ListBox.page=0
          s.create_image()
          self.file=s.get_file()
          self.name=s.get_name()
          e32.ao_sleep(0,self.carica_immagine)
          self.caricato=0
          self.create_image()
          self.redraw_img((),0)

        def previous(self):
          if ListBox.current()>0:
            ListBox.position-=1
          else:
            ListBox.position=len(s.content_of_dir)-1
          s.create_image()
          self.file=s.get_file()
          self.name=s.get_name()
          e32.ao_sleep(0,self.carica_immagine)
          self.caricato=0
          self.create_image()
          self.redraw_img((),0)

      
      mod_viewer(s.get_file(),s.restore_plugin_UI)

  def back_handler(s):
    giff.close()
    try:
      miso.compress_all_heaps()
    except:
      pass
    if os.path.exists(s.temp):
      if len(os.listdir(s.temp))==0:
        s.tempo1=1
      else:
        s.tempo1=len(os.listdir(s.temp))
      bakland=ui.landscape
      ui.change_screen_mode(0)
      d=progress_dialog(u"Rimozione file temporanei in corso",s.plugin_name,max=s.tempo1)
      del s.tempo1
      d.draw()
      try:
        for c in os.listdir(s.temp):
          os.remove(s.temp+c)
          d.set_title(to_unicode(c))
          d.forward()
          d.draw()
        os.removedirs(s.temp)
        d.set_title(s.temp)
        d.forward()
        d.draw()
      except Exception,e:
        print str(e)
      d.close()
      ui.change_screen_mode(bakland)
    plugins.stop_module(1,s.restore)

  def keys(s):
    ui.bind(EKey5,s.info)
    ui.bind(EKey8,s.extract)
    ui.bind(EKey2,s.extract_one)

  def extract_one(s):
    if not user.query(u"Estrarre il file %s nella cartella %s"%(to_unicode(os.path.basename(s.get_file()))[:-4],to_unicode(s.extractdir)),s.plugin_name,left=u"Estrai"):
      return
    import sysinfo
    #molto approssimativa
    if os.path.getsize(s.filename)/giff.total()>sysinfo.free_drivespace()[s.filename[0:2].capitalize()]:
      user.note(u"Spazio su disco insufficiente per continuare!\nEliminare qualche dato e riprovare",s.plugin_name)
      return
    d=progress_dialog(u"Estrazione immagine in corso...",u"Creazione cartella",max=1)
    d.draw()
    d.forward()
    d.set_title(to_unicode(os.path.basename(s.get_file())))
    d.draw()
    s.extract_file(ListBox.current()+1)
    d.close()
    user.note(u"Estrazione del file %s completata!"%(to_unicode(os.path.basename(s.get_file()))[:-4]),s.plugin_name)

  def extract(s):
    if not user.query(u"Estrarre il contenuto del file GIF nella cartella %s"%(to_unicode(s.extractdir)),s.plugin_name,left=u"Estrai"):
      return
    import sysinfo
    if os.path.getsize(s.filename)>sysinfo.free_drivespace()[s.filename[0:2].capitalize()]:
      user.note(u"Spazio su disco insufficiente per continuare!\nEliminare qualche dato e riprovare",s.plugin_name)
      return
    bakland=ui.landscape
    ui.change_screen_mode(0)
    d=progress_dialog(u"Estrazione immagini in corso...",u"Creazione cartella",max=giff.total())
    i=1
    d.draw()
    while i<giff.total()+1:
      d.forward()
      d.set_title(to_unicode(s.file_name(i)))
      d.draw()
      s.extract_file(i)
      i+=1
    d.close()
    ui.change_screen_mode(bakland)
    user.note(u"Estrazione completata!",s.plugin_name)

  def extract_file(s,number):
    if not os.path.exists(s.extractdir):
      os.makedirs(s.extractdir)
    s.tempoimg=giff.image(number,s.extractdir+s.file_name(number))

  def restore(s):
    ListBox.mode_cb,ListBox.sel_cb,ListBox.right_cb,ListBox.left_cb=s.old_cbs

  def restore_plugin_UI(s,to_elem=None,ui_state=None):
    if ui_state:
      ui.set_state(ui_state)
    if ui.mode_callback!=None: ui.mode_callback()
    ListBox.select_item(ListBox.current())
    ui.unbind(EKey0)