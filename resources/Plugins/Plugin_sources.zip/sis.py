_plugin_version_=0.3 #versione
_winfile_version_=1.04 #Versione programma minore necessaria per l'utilizzo del plugin
_date_='07/2009'
_description_=u"SiS Plugin by Memory\nOriginal code (sis manager class) by Atrant (atrant@front.ru), taken from SisBoom!\nVersion: %s\n%s"%(str(_plugin_version_),_date_)

# """
# Based on Atrant's good work! The code to manage sis files is taken from sisboom and modified and improved by me.
# version .1 alpha:
# -initial version
# version .2 alpha:
# -a lot of "range" changed with more efficient "xrange"
# -code optimized, removed some unuseful code
# -extraction of the whole sis
# -sis details
# -some bug fixes
# -code cleaned
# -file sizes displayed
# -elements are now correctly alfabetically sorted, directories first
# -some more header information added to sis_parser (like max size, destination drive etc...
# version .3
# -code completely (and finally) cleaned and optimized, renamed some function/variable names
# -now if there is a filename without ext or ., it's displayed correctly as a file and not as a dir
# -plugin cleaned completely from winfile after selecting "Install" (it opens installer by system) and not "Explore"
# -completely unicode: it supports now all non ascii character (filename and/or sis content)
# -added sis details: type and component name
# -completely rewritten (or better rewritten by myself ;)) extraction system: multiselection, directories and possibility to abort and a cool graphic bar
# """

EXTRACTION_BUFFER = 10240 #10 KB estratti, decompressi e sritti. Alzare per velocit� maggiore (opzione?)

import zlib,os,time

def ru(x):
    return x.decode('utf-8')
def ur(x):
    return x.encode('utf-8')

class FILE_READER:
    def open_file(self, path):
        try:
            self.fo = open(path, 'rb')
            return True
        except:
            return False
    def read_2byte_as_int(self):
        t_s = self.fo.read(2)
        char = ((ord(t_s[1]) * 256) + ord(t_s[0]))
        return char
    def read_4byte_as_int(self):
        t_s = self.fo.read(4)
        char = ((((ord(t_s[3]) * 16777216) + (ord(t_s[2]) * 65536)) + (ord(t_s[1]) * 256)) + ord(t_s[0]))
        return char
    def read(self, size):
        return self.fo.read(size)
    def read_utf16(self, size):
        return self.read(size).decode('UTF-16LE')
    def seek(self, addr, m = 0):
        self.fo.seek(addr, m)
    def tell(self):
        return self.fo.tell()
    def close(self):
        self.fo.close()

class sis_parser:
#Sis file reading class
    #Modded by Memory (some properties reading added)
    #v2->load function, file list & data inside
    def __init__(self, file):
        self.filelist = []
        self.filedata = []
        self.data = {} #{name: [name,compr. size, position, real size}
        self.uid=0
        self.version=[0,0,0]
        self.global_drive=''
        self.max_uncompressed_size = 0
        self.sis_file = file
        self.target_directory = u'%s_unpack\\'%to_unicode(file)
        self.total_files = 0
        self.sis_options = 0
        self.sis_type = 0
        self.languages_number = 0
        self.language_pointer = 0
        self.component_name = u""
        self.files_pointer = 0
        self.is_compressed = True
        self.language_list = []
        self.is_valid = False
        self.br = FILE_READER()
        self.extraction_info = sis_parser.EXTRACT_INFO()
        if file and self.br.open_file(file):
            self.read_header()
            self.is_valid = True

    def read_header(self):
        self.br.seek(0)
        self.uid = self.br.read_4byte_as_int()
        self.br.seek(18)
        self.languages_number = self.br.read_2byte_as_int()
        self.br.seek(20)
        self.total_files = self.br.read_2byte_as_int()
        self.br.seek(28)
        self.global_drive=self.br.read(1)
        self.br.seek(36)
        self.sis_options = self.br.read_2byte_as_int()
        if (self.sis_options & 8) == 8:
            self.is_compressed = False
        self.br.seek(38)
        self.sis_type = self.br.read_2byte_as_int()
        self.br.seek(40) #Majour version
        self.version[0] = self.br.read_2byte_as_int()
        self.br.seek(42) #Minour version
        self.version[1] = self.br.read_2byte_as_int()
        self.br.seek(44) #Build version
        self.version[2] = self.br.read_2byte_as_int()
        self.br.seek(48)
        self.language_pointer = self.br.read_4byte_as_int()
        self.br.seek(52)
        self.files_pointer = self.br.read_4byte_as_int()
        self.br.seek(self.language_pointer)
        for i in xrange(self.languages_number):
            c = self.br.read_2byte_as_int()
            self.language_list.append(self.language_parser(c))
        self.br.seek(80)
        self.max_uncompressed_size = self.br.read_4byte_as_int()
        #new
        self.br.seek(64)
        self.br.seek(self.br.read_4byte_as_int())
        len=self.br.read_4byte_as_int()
        self.br.seek(self.br.read_4byte_as_int())
        try: self.component_name = self.br.read_utf16(len)
        except: pass

    def language_parser(self, id):
        lang_list = {
            0: u'Test',1: u'EN',2: u'FR',3: u'GE',4: u'SP',5: u'IT',6: u'SW',7: u'DA',8: u'NO',9: u'FI',10: u'AM',
            11: u'SF',12: u'SG',13: u'PO',14: u'TU',15: u'IC',16: u'RU',17: u'HU',18: u'DU',19: u'BL',20: u'AU',21: u'BG',22: u'AS',
            23: u'NZ',24: u'IF',25: u'CS',26: u'SK',27: u'PL',28: u'SL',29: u'TC',30: u'HK',31: u'ZH',32: u'JA',33: u'TH',
            34: u'AF',35: u'SQ',36: u'AH',37: u'AR',38: u'HY',39: u'TL',40: u'BE',41: u'BN',42: u'BulG',43: u'MY',44: u'CA',
            45: u'HR',46: u'CE',47: u'IE',48: u'SouthAF',49: u'ET',50: u'FA',51: u'CF',52: u'GD',53: u'KA',54: u'EL',55: u'CG',
            56: u'GU',57: u'HE',58: u'HI',59: u'IN',60: u'GA',61: u'SZ',62: u'KN',63: u'KK',64: u'KM',65: u'KO',66: u'LO',
            67: u'LV',68: u'LT',69: u'MK',70: u'MS',71: u'ML',72: u'MR',73: u'MO',74: u'MN',75: u'NN',76: u'BP',77: u'PA',78: u'RO',
            79: u'SR',80: u'SI',81: u'SO',82: u'OS',83: u'LS',84: u'SH',85: u'FS',87: u'TA',88: u'TE',89: u'BO',90: u'TI',
            91: u'CT',92: u'TK',93: u'UK',94: u'UR',96: u'VI',97: u'CY',98: u'ZU'}
        if id in lang_list:
            return lang_list[id]
        else:
            return unicode(id)

    def load(s):
        err=0
        s.br.seek(s.files_pointer)
        for i in xrange(s.total_files):
            try:
                s1,s2=s.listsis()
                s.filelist+=s1
                s.filedata+=s2
            except:
                err+=1
        s.filelist=map(os.path.normcase,s.filelist)
        s.data=dict(zip(s.filelist,s.filedata))
        s.br.close()
        return err

    def is_file(self,s):
        if os.path.isdir(ur(s)):
            return False
        for i in xrange((len(s) - 1), -1, -1):
            if s[i] == '\\':
                return False
            elif s[i] == '.':
                return True
        return False

    class EXTRACT_INFO:
        def __init__(s):
            s.store_type = 0 #Tipo di file in generale
            s.file_type = 0 #Tipo di file in particolare
            s.popup_type = 0 #Tipo di popup (messaggio con continua, annulla ecc...), oppure tipo di avvio o tipo di apertura
            s.orig_path_lenght = 0 #Source path (file location during sis creation)
            s.orig_path_position = 0
            s.name_lenght = True #Destination
            s.name_pos = 0
            s.multilanguage = False

    def normalize_filename(self, s): #???
        t_s = s[2:]
        t_s = t_s.replace('*', '[asterisk]')
        t_s = t_s.replace(':', '[colon]')
        t_s = t_s.replace(';', '[semicolon]')
        return (s[:2] + t_s)

    def listsis(self):
        lista_file=[]
        files_details_list=[]
        init_pos = self.br.tell()
        extraction_info = self.extraction_info
        extraction_info.store_type = self.br.read_4byte_as_int()
        if (extraction_info.store_type < 2):
            if (extraction_info.store_type == 1):
                self.multilanguage = True
            elif (extraction_info.store_type == 0):
                self.multilanguage = False
            extraction_info.file_type = self.br.read_4byte_as_int()
            extraction_info.popup_type = self.br.read_4byte_as_int()
            extraction_info.orig_path_lenght = self.br.read_4byte_as_int()
            extraction_info.orig_path_position = self.br.read_4byte_as_int()
            extraction_info.name_lenght = self.br.read_4byte_as_int()
            extraction_info.name_pos = self.br.read_4byte_as_int()
            curr_position = self.br.tell()
            self.br.seek(extraction_info.name_pos)
            name = self.br.read_utf16(extraction_info.name_lenght)
            name = name.replace(':\\', '\\')
            self.br.seek(curr_position)
            languages_number = -1
            if (extraction_info.file_type == 0): #File normale
                languages_number = 1
            elif (extraction_info.file_type == 1): #File da visualizzare durante l'installazione
                if (name == ''):
                    try:
                        file_position_1 = self.br.tell()
                        self.br.seek(extraction_info.orig_path_position)
                        testo = self.br.read_utf16(extraction_info.orig_path_lenght)
                        self.br.seek(file_position_1)
                        testo = os.path.split(testo)[1]
                        name = u'popups\\' + testo
                    except:
                        name = ru(time.strftime(u'popups\\info_%H%M%S.txt'))
                        e32.ao_sleep(1)
                languages_number = 1
            elif (extraction_info.file_type == 2): #Altro file sis da installare
                try:
                    file_position_1 = self.br.tell()
                    self.br.seek(extraction_info.orig_path_position)
                    sis_component_name = self.br.read_utf16(extraction_info.orig_path_lenght)
                    self.br.seek(file_position_1)
                    sis_component_name = os.path.split(sis_component_name)[1]
                    if (sis_component_name == ''):
                        raise
                    name = u'siscomponents\\' + sis_component_name
                except:
                    name = ru(time.strftime(u'SisComponent_%H%M%S.sis'))
                    e32.ao_sleep(1)
                languages_number = 1
            elif (extraction_info.file_type == 3): #File da eseguire
                languages_number = 1
            elif (extraction_info.file_type == 4): #Il file non esiste nel file sis ma verr� creato
                languages_number = -1
            elif (extraction_info.file_type == 5): #File da aprire
                languages_number = 1
            if (languages_number > 0):
                lista_file = []
                for i in xrange(languages_number):
                    if languages_number == 1:
                        name_temp = name
                    else:
                        name_temp = u"%s_%s\\%s"%(os.path.split(name)[0],self.language_list[i],os.path.split(name)[1])#(((os.path.split(name)[0] + u'_') + self.language_list[i]) + u'\\') + os.path.split(name)[1]
                    lista_file.append(name_temp)
                    #target_files.append((self.target_directory + name_temp))
                    sz=self.br.read_4byte_as_int()
                    files_details_list.append([name_temp,sz,0,0])
                for i in xrange(languages_number):
                    pos=self.br.read_4byte_as_int()
                    files_details_list[i][2]=pos
                    files_details_list[i][3]=self.br.read_4byte_as_int()
                self.br.seek((((init_pos + 32) + (12 * languages_number)) + 4))
        elif (extraction_info.store_type == 2):
            pos_tmp = self.br.read_4byte_as_int()
            self.br.seek((((init_pos + 8) + ((8 * pos_tmp) * self.languages_number)) + 16))
        elif (extraction_info.store_type == 3) or (extraction_info.store_type == 4):
            ss = self.br.read_4byte_as_int()
            self.br.seek(ss, 1)
        return lista_file,files_details_list

    # def extract_files_and_info(self, rw, info_only = 0):
        # run = False
        # init_pos = self.br.tell()
        # extraction_info = self.extraction_info
        # extraction_info.store_type = self.br.read_4byte_as_int()
        # if (extraction_info.store_type < 2): #Simple file line oppure Multiple language files line
            # if (extraction_info.store_type == 1):
                # self.multilanguage = True
            # elif (extraction_info.store_type == 0):
                # self.multilanguage = False
            # extraction_info.file_type = self.br.read_4byte_as_int()
            # extraction_info.popup_type = self.br.read_4byte_as_int()
            # extraction_info.orig_path_lenght = self.br.read_4byte_as_int()
            # extraction_info.orig_path_position = self.br.read_4byte_as_int()
            # extraction_info.name_lenght = self.br.read_4byte_as_int()
            # extraction_info.name_pos = self.br.read_4byte_as_int()
            # curr_position = self.br.tell()
            # self.br.seek(extraction_info.name_pos)
            # name = self.br.read_utf16(extraction_info.name_lenght)
            # if ((extraction_info.file_type != 1) and (extraction_info.file_type != 2)):
                # rw.write('\r\n%s\r\nFile type: '%ur(name))
            # name = name.replace(u':\\', u'\\')
            # self.br.seek(curr_position)
            # languages_number = -1
            # if (extraction_info.file_type == 0): #File normale
                # languages_number = 1
                # rw.write('Standard\r\n')
            # elif (extraction_info.file_type == 1): #File da visualizzare durante l'installazione
                # if (name == ''):
                    # try:
                        # file_position_1 = self.br.tell()
                        # self.br.seek(extraction_info.orig_path_position)
                        # testo = self.br.read_utf16(extraction_info.orig_path_lenght)
                        # self.br.seek(file_position_1)
                        # testo = os.path.split(testo)[1]
                        # if (testo == ''):
                            # raise 
                        # name = u'popups\\' + testo
                    # except:
                        # name = ru(time.strftime(u'popups\\info_%H%M%S.txt'))
                        # e32.ao_sleep(1)
                # languages_number = 1
                # rw.write('\r\n')
                # rw.write(ur(name))
                # rw.write('\r\n')
                # rw.write('File type: popup info')
                # rw.write('\r\n')
                # rw.write('Actions: ')
                # if (extraction_info.popup_type == 0): #Continua
                    # rw.write("Continue installation")
                # elif (extraction_info.popup_type == 1): #Tralascia file
                    # rw.write("Continue installation, skip file")
                # elif (extraction_info.popup_type == 2): #Annulla installazione
                    # rw.write("Continue installation, abort installation")
                # elif (extraction_info.popup_type == 3): #Annulla installazione e rimuovi tutte le modifiche
                    # rw.write("Continue installation, abort installation and undo changes")
                # rw.write('\r\n')
            # elif (extraction_info.file_type == 2): #Altro file sis da installare
                # run = True
                # try:
                    # file_position_1 = self.br.tell()
                    # self.br.seek(extraction_info.orig_path_position)
                    # sis_component_name = self.br.read_utf16(extraction_info.orig_path_lenght)
                    # self.br.seek(file_position_1)
                    # sis_component_name = os.path.split(sis_component_name)[1]
                    # if (sis_component_name == ''):
                        # raise 
                    # name = u'siscomponents\\' + sis_component_name
                # except:
                    # name = ru(time.strftime('SisComponent_%H%M%S.sis'))
                    # e32.ao_sleep(1)
                # languages_number = 1
                # rw.write('\r\n')
                # rw.write(ur(name))
                # rw.write('\r\n')
                # rw.write('File type: ')
                # rw.write('Sis component')
                # rw.write('\r\n')
            # elif (extraction_info.file_type == 3): #File da eseguire
                # run = True
                # languages_number = 1
                # rw.write('Autostarts')
                # rw.write('\r\n')
                # rw.write('Activation type: ')
                # if (extraction_info.popup_type == 0):
                    # rw.write('During installation')
                # elif (extraction_info.popup_type == 1):
                    # rw.write('During removal')
                # elif (extraction_info.popup_type == 2):
                    # rw.write('During installation and removal')
                # elif (extraction_info.popup_type == 256):
                    # rw.write('Close when installation complete')
                # elif (extraction_info.popup_type == 512):
                    # rw.write('Wait until closed before continuing')
                # rw.write('\r\n')
            # elif (extraction_info.file_type == 4): #Il file non esiste nel file sis ma verr� creato
                # languages_number = 1
                # rw.write("Created by application: ")
                # rw.write('\r\n')
            # elif (extraction_info.file_type == 5): #File da aprire
                # languages_number = 1
                # rw.write('Opened by system (MIME-type-association)')
                # rw.write('\r\n')
                # rw.write('Opening type: ')
                # if (extraction_info.popup_type == 256): #Chiudi al termine dell'installazione
                    # rw.write('Close when installation complete')
                # elif (extraction_info.popup_type == 512): #Attendi la chiusura prima di continuare
                    # rw.write('Wait until closed before continuing')
                # rw.write('\r\n')
            # else:
                # rw.write('Unknown FileType ID: %i'%extraction_info.file_type)
            # rw.write('Multilanguage: ')
            # if self.multilanguage:
                # languages_number = self.languages_number
                # rw.write('yes')
            # else:
                # rw.write('no')
            # rw.write('\r\n')
            # if (languages_number > 0):
                # lista_file = []
                # file_sizes_list = []
                # for i in xrange(languages_number):
                    # if (languages_number == 1):
                        # name_temp = name
                    # else:
                        # name_temp = u"%s_%s\\%s"%(os.path.split(name)[0],self.language_list[i],os.path.split(name)[1])#((((os.path.split(name)[0] + '_') + self.language_list[i]) + '\\') + s)
                    # lista_file.append(name_temp)
                    # file_sizes_list.append(self.br.read_4byte_as_int())
                # for i in xrange(languages_number):
                    # if (languages_number > 1):
                        # rw.write(lista_file[i])
                        # rw.write('\r\n')
                    # rw.write('File size: %i bytes\n'%file_sizes_list[i])
                # self.br.seek((((init_pos + 32) + (12 * languages_number)) + 4))
        # elif (extraction_info.store_type == 2):
            # s56 = self.br.read_4byte_as_int()
            # self.br.seek((((init_pos + 8) + ((8 * s56) * self.languages_number)) + 16))
        # elif (extraction_info.store_type == 3) or (extraction_info.store_type == 4):
            # ss = self.br.read_4byte_as_int()
            # self.br.seek(ss, 1)
        # elif (extraction_info.store_type == 5) or (extraction_info.store_type == 6):
            # pass
        # else:
            # rw.write('Sis file entry error! Unknown file type: %i'%extraction_info.store_type)
        # if run:
            # rw.write('Automatically Activated')

class init_plugin:
    def __init__(s,module,filename):
        globals().update(module)
        if user.query(u"Installare o visualizzare il file sis?",u"Sis Plugin",left=u"Installa",right=u"Esplora"):
            e32.start_exe(u'z:\\system\\programs\\apprun.exe',u'Z:\\System\\Apps\\AppInst\\Appinst.app O"%s"'%to_unicode(filename))
            plugins.clean_module()
            return
        s.size_format=1 #1: compressed; 3: real
        s.data_file=directory.data_dir+"\\sis_plugin.dat"
        s.dir=u""
        s.content_of_dir=[]
        s.archive_path=filename
        s.archive_path_uni=to_unicode(filename)
        s.parser = sis_parser(s.archive_path)
        if not s.parser.is_valid:
            user.note(u"File in uso o non accessibile.")
            plugins.clean_module()
            return
        error=s.parser.load()
        if not s.parser.data:
            user.note(u"Il file sis sembra danneggiato o non contiene alcun elemento valido.",u"Sis Plugin")
            plugins.clean_module()
            return
        if error:
            user.note(u"File sis parzialmente illeggibile o danneggiato...\nAlcuni componenti non saranno visibili.",u"Sis Plugin")
        s.remember(0)
        s.scan()
        ListBox.reset()
        s.keys()
        ListBox.mode_cb=s.keys
        ListBox.sel_cb=s.go
        ListBox.right_cb=lambda: s.go(1)
        ListBox.left_cb=s.back_handler
        ui.menu.menu(main.select_menu+
                    [(u"Estrai...",
                            [(u"Singolo o selez. [2]",s.unpack),(u"Tutto [8]",s.unpack_all)]),
                    (u"Opzioni",
                            [(u"Dimens. visualizzata",s.opzione_grandezza)]),
                    (u"Dettagli elemento [5]",[s.file_details]),
                    (u"Dettagli Sis [1]",[s.sis_details]),
                    (u"Plugin Info",[s.about])]+main.exit_menu)
        s.set_list()

    def about(s):
        user.note(_description_,u"SIS Plugin",-1)

    def keys(s):
        ui.bind(EKey5,s.file_details)
        ui.bind(EKey8,s.unpack_all)
        ui.bind(EKey2,s.unpack)
        ui.bind(EKey1,s.sis_details)

    def opzione_grandezza(s):
        if user.query(u"Dimensione visualizzata:\nCompr.: dimensione file all'interno del sis\nReale: dimensione non compressa, file estratto",u"Opzioni Sis Plugin",left=u"Compressa",right=u"Reale"):
            s.size_format=1
        else:
            s.size_format=3
        s.remember(1)
        s.scan()
        s.set_list(ListBox.current())

    def remember(s,t):
        if t:
            try: open(s.data_file,'wb').write(chr(s.size_format))
            except: pass
        else:
            try: s.size_format=ord(open(s.data_file).read(1))
            except: pass

    def sis_details(s):
        if ((s.parser.sis_options & 8) == 8):
            ic = u"no"
        else:
            ic = u"si"
        #{0:"SA,SISAPP",1:"SY,SISSYSTEM",2:"SO,SISOPTION",3:"SC,SISCONFIG",4:"SP,SISPATCH",5:"SU,SISUPGRADE"}
        try: tp={0:u"Applicazione",1:u"Sistema",2:u"Opzione",3:u"Configurazione",4:u"Patch",5:u"Aggiornamento"}[s.parser.sis_type]
        except: tp=u'sconosciuto'
        ver=u"%i.%i.%i"%(s.parser.version[0],s.parser.version[1],s.parser.version[2])
        lng=u"-".join(s.parser.language_list)
        text=u"Files: %i\nLingue: %s\nCompresso: %s\nUID: 0x%x\nVersione: %s\nDrive: %s\nDim. max: %s\nComponente: %s\nTipo: %s"%(s.parser.total_files,lng,ic,s.parser.uid,ver,s.parser.global_drive,dataformatter.sizetostr(s.parser.max_uncompressed_size),s.parser.component_name,tp)
        user.note(text,u"Dettagli installer",-1)
        del text

    def file_details(s):
        file=s.get_file()
        if s.is_file(file):
            info=s.get_file_info()
            text=u"Dimensione nel file sis: %s\nDimensione reale: %s"%(dataformatter.sizetostr(info[1]),dataformatter.sizetostr(info[3]))
        else:
            tmp=[]
            s.lista(file,tmp)
            tsz=0
            tszc=0
            for i in tmp:
                tsz+=s.parser.data[i][3]
                tszc+=s.parser.data[i][1]
            text=u"Elementi: %i\nDimensione totale\nCompressa: %s\nReale: %s"%(len(tmp),dataformatter.sizetostr(tszc),dataformatter.sizetostr(tsz))
        user.note(text,os.path.split(file)[1],-1)
        del text

    def back_handler(s):
        if not s.dir:
            plugins.stop_module(1)
        else:
            s.back()

    def set_list(s,position=0):
        ListBox.elements=[]
        ListBox.selected=[]
        d=u"%s>%s"%(os.path.split(s.archive_path_uni)[1],s.dir)
        ListBox.no_data=u"La cartella %s non contiene elementi"%d
        u=None
        dir_ico=[grafica.cartella_img,grafica.cartella_mask]
        for path,name,type,size in s.content_of_dir:
            try:
                if type==1:
                    if settings.get_size_on_canvas: u=dataformatter.sizetostr(size)
                    else: u=None
                    ListBox.elements.append(LType(name,u,d,icon=ext_util.search_path(name)[1]))
                else:
                    ListBox.elements.append(LType(name,title=d,icon=dir_ico))
            except:
                ListBox.elements.append(LType(name=u"Errore visualizzazione",title=u"Errore elemento"))
        ListBox.select_item(position)

    def get_file(s,se=0):
        if se:
            return map(lambda i: s.content_of_dir[i][0], ListBox.selected)
        else:
            return s.content_of_dir[ListBox.current()][0]

    def get_file_info(s,id=None):
        #return s.whole_sis_elements_details[s.parser.filelist.index(s.content_of_dir[ListBox.current()][0])]
        if id:
            return s.parser.data[id]
        else:
            return s.parser.data[s.get_file()]

    def is_file(s,n):
        if n in s.parser.filelist:
            return True
        return False

    def scan(s):
        d,f=[],[]
        for file in s.listdir(s.dir,s.parser.filelist):
            path=os.path.join(s.dir,file)
            if s.is_file(path):#s.whole_sis_elements_details[s.parser.filelist.index(path)]
                f.append((path,file,1,s.parser.data[path][s.size_format]))
            else:
                d.append((s.normpath(path),file,0,0))
        s.content_of_dir=d+f
        del d,f

    def go(s,k=0):
        if s.content_of_dir:
            fn=s.get_file()
            if not s.is_file(fn):
                s.dir=fn
                s.scan()
                s.set_list()
            elif k==0:
                s.unpack()
                #user.note(u"Impossibile aprire i file direttamente!\nPer ora � disponible solamente l'estrazione singola o totale.",u"Non disponibile",-1)

    def back(s):
        if s.dir.count(u'\\')<=1:
            w=s.dir.strip(u'\\')
            s.dir=u''
        else:
            x=s.dir.split(u'\\')
            x=x[0:len(x)-1]
            w=x[-1]
            x=x[0:len(x)-2]
            s.dir=s.dir[:-(len(w)+1)]
        s.scan()
        s.set_list(w)

    def normpath(s,x):
        if x[-1] == u'\\':
            return x
        else:
            return x + u'\\'

    def listdir(s,dire,list):
        tmp=[]
        if dire in [u"",u"\\"]:
            for i in list:
                path=i.split("\\")[0]
                if not path in tmp:
                    tmp.append(path)
        else:
            dire=s.normpath(dire)
            for i in list:
                try: value=(i.split(dire)[1]).split("\\")
                except: continue
                t=value[0]
                if not t in tmp: tmp.append(t)
        tmp=s.alfabetico(tmp)
        return tmp

    def alfabetico(s,lista):
        _lista_lower=map(lambda x: x.lower(),lista)
        _lista_lower_orig=_lista_lower[:]
        _lista_lower.sort()
        return map(lambda i: lista[i],map(_lista_lower_orig.index,_lista_lower))
#Da arc.py ;)
    def lista(s,path,list):
        for child in s.listdir(path,s.parser.filelist):
            tpath=os.path.join(path,child)
            if s.is_file(tpath):
                list.append(tpath)
            else:
                s.lista(tpath,list)

    def unpack(s):
        #Wrapper della funzione unpack_all con una query
        title=u"Estrazione"
        key=u"Estrai"
        name=s.get_file()
        tmp=[]
        if ListBox.selected:
            if user.query(u"Estrarre gli elementi selezionati?",title,left=key):
                for i in s.get_file(1):
                    if s.is_file(i):
                        tmp.append(i)
                    else:
                        s.lista(i,tmp)
                s.unpack_all(tmp)
        else:
            if s.is_file(name):
                if user.query(u"Estrarre il file %s?"%os.path.basename(name),title,left=key):
                    s.unpack_all([name])
            else:
                s.lista(name,tmp)
                if user.query(u"Estrarre tutti gli elementi presenti (%i) nella cartella?"%len(tmp),title,left=key):
                    s.unpack_all(tmp)

    def unpack_all(s,list=None):
        target = s.parser.target_directory
        ic = s.parser.is_compressed
        import zlib
        s.running=1
        total_written=0
        if not (list in [[],None]):
            num=len(list)
            files=list
            tsz=0
            for i in list:
                tsz+=s.parser.data[i][3]
        else:
            num=len(s.parser.filelist)
            files=s.parser.filelist
            tsz=0
            for i in files:
                tsz+=s.parser.data[i][3]
        if tsz==0: tsz=0.0001 #Risolve un bug: se la dimensione � 0
        def abort():
            s.running=0
        s.parser.br.open_file(s.parser.sis_file)
        d=progress_dialog(u"Inizializzazione\n\n",u"Estrazione elementi",max=tsz,break_cb=abort)
        d.draw()
        for i in xrange(0,num):
            bytes_written=0
            name=files[i]
            name,sz,pos,dim=s.get_file_info(name) #name � il percorso non minuscolizzato (in precedenza per risolvere un bug)
            d.to_draw[-2]=name
            d.to_draw[-1]=u"(%i di %i)"%(i+1,num)
            d.draw()
            #name=name.replace('C:\\',s.extract_dir)
            name=s.parser.normalize_filename(target + name)
            try: os.makedirs(os.path.split(ur(name))[0])
            except: pass
            try:
                s.parser.br.seek(pos)
                zlib_class = zlib.decompressobj()
                b=open(ur(name),'wb',EXTRACTION_BUFFER)
                if dim==0:
                    pass
                elif ic:
                    while (bytes_written < dim) and (s.running):
                        temp_bytes = s.parser.br.read(EXTRACTION_BUFFER)
                        temp_bytes = zlib_class.decompress(temp_bytes)
                        bytes_written += len(temp_bytes)
                        b.write(temp_bytes)
                        d.update_state(total_written+bytes_written)
                        d.draw()
                        e32.ao_yield()
                else:
                    while (bytes_written < dim) and (s.running):
                        temp = s.parser.br.read(min(EXTRACTION_BUFFER, (dim - bytes_written)))
                        b.write(temp)
                        bytes_written += len(temp)
                        d.update_state(total_written+bytes_written)
                        d.draw()
                        e32.ao_yield()
                b.close()
            except Exception,e:
                user.note(unicode(e))
                # error=1
            total_written+=dim
            if not s.running:
                try: os.remove(ur(name))
                except: pass
                break
            #e32.ao_yield()
        d.close()
        try: b.close() #Se ad esempio � avvenuto un errore e il file non si � chiuso correttamente
        except: pass
        s.parser.br.close() #Chiude il file sis