#Version 1.2: - code cleaned, unesufull code removed; - bugfix regarding uid searching (correct long number format); - file refreshed (you can see backup file)
# - language: English
_plugin_version_=1.2 
_winfile_version_=1.04
_description_=u"Theme plugin by Memory\nVersion: %s\nIt reads some properties of the skn file and gives the possibility to rename the theme."%str(_plugin_version_)
import struct
def hexstring(x, size = 2):
    string = str(hex(x))[2:]
    if len(string) < size:
        string = (('0' * (size - len(string))) + string)
    if size == 4:
        string = (string[2:4] + string[:2])
    if size == 8:
        string = (((string[6:8] + string[4:6]) + string[2:4]) + string[0:2])
    return string
def hex0(x):
    return x.decode('hex')

header='\x00\x01\x00\x01\x00\x01\x00'
theme_app="Z:\\System\\Apps\\psln\\psln.app"

class init_plugin:
    def __init__(s,module,filename):
        globals().update(module)
        s.filename=filename
        #print ListBox.elements
        ListBox.elements=[]
        ListBox.selected=[]
        ListBox.reset() #Reimposta solo i tasti necessari per controllare la listbox
        ListBox.left_cb=lambda: plugins.stop_module(1)
        ListBox.sel_cb=s.details
        ListBox.no_data=u"Invalid theme file or read error!"
        ui.menu.menu([(u"Rename",[lambda: s.rename(s.filename)]),
                      (u"Details",[s.details]),
                      (u"Themes...",[lambda: start(file=theme_app)]),
                      (u"Plugin Info",[s.about])]+main.exit_menu)
        s.update_view()

    def update_view(s):
        ListBox.elements=[]
        ListBox.selected=[]
        for elem,value in [(u"Theme Name","s.get_name(s.filename)"),
                               (u"Copyright/Author","s.get_copyright(s.filename)"),
                               (u"Uid","s.get_uid(s.filename)")]:
            try:
                value=to_unicode(eval(value))
                if value: ListBox.elements.append(LType(name=elem,undername=value,title=to_unicode(os.path.basename(s.filename))))
            except Exception,e:
                print str(e)
        ListBox.select_item(0)

    def details(s):
        title=ListBox.elements[ListBox.current()].name
        txt=ListBox.elements[ListBox.current()].undername
        user.note(txt,title,-1)

    def get_name(s,file):
        f=open(file,'rb')
        get=f.read()
        f.close()
        i = get.find(header)
        if (i == 0) or (i==-1):
            return None
        else:
            lenthcode = ord(get[(i + 7):(i + 8)])
            skinname = get[(i + 9):((i + 9) + (lenthcode * 2))].decode('utf16')
            del get
            return skinname

    def rename(s,path):
        file = open(path, 'rb')
        get = file.read()
        file.close()
        i = get.find(header)
        if i == 0:
            user.note(u"Invalid theme file!")
            return
        else:
            lenthcode = ord(get[(i + 7):(i + 8)])
            name = get[(i + 9):((i + 9) + (lenthcode * 2))].decode('utf16')
        name = appuifw.query(u"New name:", 'text', name)
        if name:
            e32.ao_sleep(0.2)
            try:
                if not os.path.exists(path + '_old'):
                    user.direct_note(u"Writting backup file...",u"Theme plugin")
                    file = open((path + '_old'), 'w')
                    file.write(get)
                    file.close()
                N = len(name)
                total = hexstring((((ord(get[1:2]) * 256) + ord(get[:1])) + ((N - lenthcode) * 2)))
                if (len(total) < 4):
                    n0 = (4 - len(total))
                    total = (('0' * n0) + total)
                    del n0
                total = (total[2:4] + total[:2])
                user.direct_note(u"Writting skn file...",u"Theme plugin")
                file = open(path, 'w')
                file.write((((((((hex0(total) + get[2:(i - 3)]) + hex0(hexstring(((2 * N) + 13)))) + get[(i - 2):(i + 7)]) + hex0(hexstring(N))) + get[(i + 8):(i + 9)]) + name.encode('utf16')[2:]) + get[((i + 9) + (lenthcode * 2)):]))
                file.close()
                del get
                del N
                del lenthcode
                del i
                del total
                user.note(u"Theme correctly renamed!\nYou can find a backup (original) copy of the file with .skn_old extension.",u"Theme plugin",-1)
                s.update_view()
            except Exception,e:
                user.note(u"Error renaming theme file...\nDetails: %s"%unicode(e),u"Theme plugin",-1)

    def get_uid(s,file):
        f=open(file,'rb') #File skn
        f.seek(0x08)
        i=hex(struct.unpack('L',f.read(4))[0]).strip('L')
        f.close()
        return i

    def get_copyright(s,file):
        c=''
        f=open(file,'rb') #File skn
        f.seek(0x44)
        while 1:
            p=f.read(1)
            if p in ['\xf5','\x02',''] : break
            c+=p
        try: c=c.decode("utf16") #Se � subito in forma giusta
        except: 
            try: c=c[:-1].decode("utf16") #se dovesse esserci un byte in pi� (lung. dispari)
            except: c=u""
        f.close()
        if c=='u\x0000': c=u''
        elif c=='\x00': c=u''
        return c

    def about(s):
        user.note(_description_,u"SKN Plugin",-1)