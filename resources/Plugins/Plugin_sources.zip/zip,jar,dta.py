#'''WINFILE PLUGIN'''
#Zip archives (*.zip) plugin for WinFile
#Variabili OBBLIGATORIE
_plugin_version_=1.1 #versione
_winfile_version_=1.04 #Versione programma minore necessaria per l'utilizzo del plugin
_description_=u'Plugin di WinFile che implementa la possibilit� di esplorare e aprire i files all''interno di archivi zip.'

import zipfile

class init_plugin:
    def __init__(s,module,filename):
        #s.winfile=__import__(module)
        #Con questo comando importiamo tutto il namespace di winfile, cosi da poter usare le sue risorse
        globals().update(module)
        if (filename[-3:]).lower()=='jar':
            if user.query(u"Installare o visualizzare il file jar?",u"Zip Plugin",left=u"Installa",right=u"Esplora"):
                e32.start_exe(u'z:\\system\\programs\\apprun.exe',u'Z:\\System\\Apps\\AppInst\\Appinst.app O"%s"'%to_unicode(filename))
                return
        s.dir="" #Stringa vuota = directory radice
        s.content_of_dir=[]
        s.size_format=0 #or 1 for compress
        s.clean_temp_files=1 #clean temp files
        s.dir_info_files=0
        s.dir_info_dirs=0
        s.dir_info_size=0
        s.dir_info_csize=0
        s.temp=os.path.join(os.path.split(filename)[0],"WF_ZIP_TEMP_%s"%(hex(int(time.time()))))
        s.data_file=directory.data_dir+"\\zip_plugin.dat"
        
        s.archive_path=filename
        if not zipfile.is_zipfile(filename):
            user.note(u"Archivio zip danneggiato o non supportato!\nNota: gli archivi con commento, la libreria zipfile non li legge.",u"Gestione archivi zip")
            plugins.plugin,plugins.active_plugin_name=None,None
            return
        s.remember(0)
        s.archive=zipfile.ZipFile(filename)
        s.scan()
        s.old_cbs=[ListBox.mode_cb,
                ListBox.sel_cb,
                ListBox.right_cb,
                ListBox.left_cb]
        ListBox.cbind() #Reimposta solo i tasti necessari per controllare la listbox
        s.keys()
        ListBox.mode_cb=s.keys#lambda:None
        ListBox.sel_cb=s.go
        ListBox.right_cb=lambda: s.go(1)
        ListBox.position,ListBox.page=0,0
        ListBox.left_cb=s.back_handler
        plugins.plugin_end_cb=s.clean #Viene chiamata anche quando si chiama la funzione main.quit [chiusura Winfile]
        ListBox.no_data=u"L'archivio compresso zip non contiene alcun file o cartella oppure � danneggiato."
        ui.menu.menu([(u"Dettagli elemento [5]",[s.view_info]),
                    (u"Estrai...",[(u"File singolo [2]",s.extract_one),(u"Tutto [8]",s.extract)]),
                    (u"Tipo dimensione",[s.opzione_grandezza]),
                    (u"Dettagli archivio",[s.view_all_info]),(u"Plugin Info",[s.about])]+main.exit_menu)
        s.set_list()

    def keys(s):
        ui.bind(EKey5,s.view_info)
        ui.bind(EKey8,s.extract)
        ui.bind(EKey2,s.extract_one)

    def about(s):
        user.note(u"ZIP Plugin by Memory\nPlugin per WinFile per gestire archivi zip: esplora & visualizza!\nVersion: 1.1 beta",u"Gestore archivi zip",-1)

    def opzione_grandezza(s):
        s.size_format=user.query(u"Scegliere il tipo di dimensione nella lista. 'Reale' corrisponde alla dimensione del file non compresso.",u"Gestore archivi zip",left=u"Compressa",right=u"Reale")
        s.remember(1)
        s.scan()
        s.set_list(ListBox.current())

    def clean(s):
        s.archive.close()
        try:
            if s.clean_temp_files:
                user.direct_note(u"Pulizia file temporanei in corso...")
                gestione_file.removedir(s.temp) #Pulizia dei file temporanei
        except Exception,e:
            user.note(u"Errore durante la pulizia dei file temporanei: %s"%unicode(e),u"Errore")

    def back_handler(s):
        if not s.dir:
            #funzione clean automaticamente chiamata da stop_module [vedi: plugins.plugin_end_cb=s.clean]
            plugins.stop_module(1,s.restore)
        else:
            s.back()

    def remember(s,t):
        if t:
            try: open(s.data_file,'wb').write(chr(s.size_format))
            except: pass
        else:
            try: s.size_format=ord(open(s.data_file).read(1))
            except: pass

    def set_list(s,position=0):
            '''LType element: name=i[0],undername=i[1],title=i[2],type=i[3],hid=i[4],icon=i[5],selected[6]'''
            ListBox.elements=[]
            ListBox.selected=[]
            d=("%s\\%s"%(os.path.split(s.archive_path)[1],s.dir)).replace("/","\\")
            d=to_unicode(d)
            try: ListBox.no_data=u"La cartella %s non contiene elementi"%d
            except: ListBox.no_data=u"La cartella non contiene elementi"
            for path,name,type,size in s.content_of_dir:
                if settings.get_size_on_canvas: u=dataformatter.sizetostr(size)
                else: u=None
                try:
                    if type==1:
                        ListBox.elements.append(LType(name=to_unicode(name),undername=u,title=d,type=0,hid=0,icon=ext_util.search_path(name)[1]))
                    elif type==0:
                        ListBox.elements.append(LType(name=to_unicode(name.strip('/')),undername=None,title=d,type=0,hid=0,icon=[grafica.cartella_img,grafica.cartella_mask]))
                    elif type==4:
                        ListBox.elements.append(LType(name=to_unicode(path),undername=to_unicode(name),title=d))
                except:# Exception,e:
                    ListBox.elements.append(LType(name=u"Errore visualizzazione",undername=None,title=u"Errore elemento",type=0))
            if len(ListBox.elements): ListBox.select_item(position)
            else: ListBox.redrawlist()

    def get_file(s):#,list=0): #ritorna percorso completo
        # if list:
            # temp=[]
            # if ListBox.selected:
                # for i in ListBox.selected:
                    # temp.append(s.content_of_dir[i][0])
            # else:
                # temp.append(s.content_of_dir[ListBox.current()][0])
            # return temp
        # else:
        return s.content_of_dir[ListBox.current()][0]

    def scan(s):
        f,d=[],[]
        s.content_of_dir=[]
        for file in s.listdir(s.dir):
            path=os.path.join(s.dir,file)
            if path.endswith("/"):
                d.append((path,file,0,0))
            else:
                info=s.archive.NameToInfo[path]
                if s.size_format:
                    f.append((path,file,1,info.compress_size))
                else:
                    f.append((path,file,1,info.file_size))
        s.content_of_dir=d+f
        del d,f

    def go(s,k=0):
        if len(s.content_of_dir)>0:
            fn=s.get_file()
            if fn.endswith('/'):
                s.dir=fn
                s.scan()
                s.set_list()
            elif k==0:
                if not os.path.exists(os.path.normpath(os.path.join(s.temp,fn))):
                    s.extract_file(s.temp,fn)
                start(mode=0,file=os.path.join(s.temp,fn),cb=s.restore_plugin_UI)

    def scan_dir_info(s,path):
            names = s.listdir(path)
            for child in names:
                tpath=path+child
                if tpath.endswith('/'):
                    s.dir_info_dirs+=1
                    s.scan_dir_info(tpath)
                else:
                    s.dir_info_files+=1
                    tt=s.archive.NameToInfo[tpath]
                    s.dir_info_size+=tt.file_size
                    s.dir_info_csize+=tt.compress_size

    def view_all_info(s):
        s.dir_info_files=0
        s.dir_info_dirs=0
        s.dir_info_size=0
        s.dir_info_csize=0
        d=time.localtime(os.path.getmtime(s.archive_path))
        d=u"%i/%i/%i %.2i:%.2i:%.2i"%(d[2],d[1],d[0],d[3],d[4],d[5])
        s.scan_dir_info('')
        t=u'Files: %i\nCartelle: %i\nTotale: %s\n " compresso: %s\n%s'%(s.dir_info_files,s.dir_info_dirs,dataformatter.sizetostr(s.dir_info_size),
        dataformatter.sizetostr(s.dir_info_csize),d)
        user.note(t,to_unicode(os.path.split(s.archive_path)[1]),timeout=-1)

    def view_info(s):
        s.dir_info_files=0
        s.dir_info_dirs=0
        s.dir_info_size=0
        s.dir_info_csize=0
        info=s.archive.NameToInfo[s.get_file()]
        d=info.date_time
        d=u"%i/%i/%i %.2i:%.2i:%.2i"%(d[2],d[1],d[0],d[3],d[4],d[5])
        if info.filename.endswith('/'):
            s.scan_dir_info(info.filename)
            t=u'Files: %i\nCartelle: %i\nTotale: %s\n " compresso: %s\n%s'%(s.dir_info_files,s.dir_info_dirs,dataformatter.sizetostr(s.dir_info_size),
            dataformatter.sizetostr(s.dir_info_csize),d)
        else:
            t=u'Dimensione: %s\n " compressa: %s\n%s'%(dataformatter.sizetostr(info.file_size),
            dataformatter.sizetostr(info.compress_size),d)
        user.note(t,to_unicode(s.content_of_dir[ListBox.current()][1].strip('/')),timeout=-1)

    def lista(s,path,list):
            names = s.listdir(path)
            for child in names:
                tpath=path+child
                if tpath.endswith('/'):
                    s.scan_dir_info(tpath)
                else:
                    list.append(tpath)

    def extract_one(s):
        total_size=0
        files=[]
        dir=s.archive_path[:-len(os.path.splitext(s.archive_path)[1])]
        # if not dir.endswith(':') and not os.path.exists(dir):
            # os.mkdir(dir)
        if not user.query(u"Estrarre %s nella cartella %s?"%(to_unicode(os.path.basename(s.get_file())),to_unicode(dir)),u"Gestore archivi zip",left=u"Estrai"):
            return
        import sysinfo
        name=s.get_file()
        if name.endswith('/'):
            s.scan_dir_info(name)
            total_size=s.dir_info_size
            s.lista(name,files)
        else:
            total_size=s.archive.NameToInfo[name].file_size
            files=[name]
        if total_size>sysinfo.free_drivespace()[dir[0:2].capitalize()]:
            user.note(u"Spazio su disco insufficiente per continuare!\nEliminare qualche dato e riprovare.",u"Gestore archivi zip")
            return
        #print files,total_size,name
        d=progress_dialog(u"Estrazione elementi in corso...",u"",max=len(files))
        for file in files:
            d.set_title(to_unicode(file.split('/')[-1]))
            d.draw()
            try: s.extract_file(dir,file)
            except: pass
            d.forward()
        d.close()

    def extract_file(s,dir,name):
        path=os.path.normpath(os.path.join(dir,name))
        try: os.makedirs(os.path.split(path)[0])
        except: pass
        outfile = open(path,'wb',10240)
        try:
            outfile.write(s.archive.read(name))
            outfile.flush()
        except: pass
        outfile.close()

    def back(s):
        if s.dir.count('/')<=1:
            try: w=to_unicode(s.dir.strip(u'/'))
            except: w=0
            s.dir=''
            #s.set_list()
        else:
            x=s.dir.split('/')
            x=x[0:len(x)-1]
            w=to_unicode(x[-1])#+'/'
            x=x[0:len(x)-2]
            s.dir=s.dir[:-(len(w)+1)]
        s.scan()
        s.set_list(w)

    def restore(s):
        ListBox.mode_cb,ListBox.sel_cb,ListBox.right_cb,ListBox.left_cb=s.old_cbs

    def restore_plugin_UI(s,to_elem=None,ui_state=None):
        if ui_state:
            ui.set_state(ui_state)
        else:
            try: ui.reload_state()
            except: pass
        if ui.mode_callback!=None: ui.mode_callback()
        if to_elem: ListBox.select_item(to_elem)

    def listdir(s,dir):
        filesystem=s.archive.namelist()
        temp=[]
        if not dir:
            for elem in filesystem:
                if elem[-1]=='/' and elem.count('/')==1: #Directory in root
                    temp.append(elem)
                elif elem.count('/')==0: #File in root
                    temp.append(elem)
            return temp
        if dir[-1]!="/":
            raise ValueError,"Invalid zip directory. It must end with '/'"
        for elem in filesystem:
            path=""
            name=""
            if elem.startswith(dir):
                path=elem[len(dir):]
                if ('/' in path):
                    n=path.split('/')
                    try:
                        if n[1]=="":
                            temp.append(path)
                    except:
                        temp.append(path)
                elif path!="":
                    temp.append(path)
        return temp

    def extract(s):
        dir=s.archive_path[:-len(os.path.splitext(s.archive_path)[1])]
        if not user.query(u"Estrarre il contenuto dell'archvio nella cartella %s?"%to_unicode(dir),u"Gestore archivi zip",left=u"Estrai"):
            return
        import sysinfo
        s.scan_dir_info("")
        if s.dir_info_size>sysinfo.free_drivespace()[dir[0:2].capitalize()]:
            user.note(u"Spazio su disco insufficiente per continuare!\nEliminare qualche dato e riprovare.",u"Gestore archivi zip")
            return
        dir=dir.replace('\\','/')
        if not dir.endswith(':') and not os.path.exists(dir):
            os.mkdir(dir)
        # create directory structure to house files
        directories=s._listdirs()
        num_files = len(s.archive.namelist())-len(directories)
        d=progress_dialog(u"Estrazione archivio in corso...",u"Creazione cartelle",max=len(s.archive.namelist()))
        for dn in directories:
            curdir = os.path.join(dir, dn)
            #if not os.path.exists(curdir):
            try: os.mkdir(curdir)
            except: pass
            d.forward()
            d.draw()
            e32.ao_yield()
        # extract files to directory structure
        #i=0
        for name in s.archive.namelist():
            if not name.endswith('/'):
                d.set_title(to_unicode(name.split('/')[-1]))
                d.draw()
                try:
                    outfile = open(os.path.join(dir, name),'wb',10240)
                    outfile.write(s.archive.read(name))
                    outfile.flush()
                    outfile.close()
                except: continue
                d.forward()
                #d.draw()
            #i+=1
            e32.ao_yield()
        d.close()
        user.note(u"Estrazione completata!",u"Gestore archivi zip")

    def _listdirs(s):
        dirs = []
        for name in s.archive.namelist():
            if name.endswith('/'):
                dirs.append(name)
        dirs.sort()
        return dirs

    # def copy_from_zip(s, self, name, stream, chunk= 10240):
        # "Funzione di copia diretta, utile per file grossi, senza dover caricare l'intero file in memoria"
        # import zlib
        # if self.mode not in ("r", "a"):
          # raise ZipError, 'piperead() requires mode "r" or "a"'
        # if not self.fp:
          # raise ZipError, "Attempt to read ZIP archive that was already closed"

        # data= self.TOC[name]
        # filepos = self.fp.tell()
        # self.fp.seek(data[0], 0)

        # nbytes= data[7]
        # format= data[3]
        # if format not in zipFormats.values():
          # self.fp.seek(filepos, 0)
          # raise ZipError, 'Unsupported compression method '+"'"+str(data[3])+"'"

        # if format==zipFormats['deflate']:
          # dc = zlib.decompressobj(-15)

        # crc= 0
        # while nbytes>0:
          # length= min(chunk, nbytes)
          # bytes= self.fp.read(length)
          # if format==zipFormats['deflate']:
            # bytes= dc.decompress(bytes)
          # crc= zlib.crc32(bytes, crc)
          # stream.write(bytes)
          # nbytes= nbytes-length

        # if format==zipFormats['deflate']:
          # bytes= dc.decompress('Z')+dc.flush()
          # if bytes:
            # crc= zlib.crc32(bytes, crc)
            # stream.write(bytes)

        # self.fp.seek(filepos, 0)
        # if crc!=data[6]:
          # raise ZipError, 'Bad CRC for file '+"'"+name+"'"
        # return
        