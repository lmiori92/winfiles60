#M3U Playlist reader-writer by Memory � 2007-2008
#Versione 1 (1.12.07)
#-Legge playlist semplici (Lettore Nokia) e poi inoltre quelle con #EXTINF
#-Scrive playlist in formato m3u, in modo semplice e con informazioni #EXTINF

#Versione 1.1 (1.11.08)
#   -Molti bugs corretti
#   -Lettura differenti "formati", codifiche di testo
#Dubbi:
# C'� differenza tra \ e // o / nei percorsi (nei lettori mp3 ad esempio)??

import os

# from os import *
# from os.path import *

# def find_drives(env):
    # L = []
    # if(env == 'WINDOWS'):
        # for i in range(ord('a'), ord('z')+1):
            # drive = chr(i)
            # if(exists(drive +":\\")):
                # L.append(drive)
        # return L
    # elif env=="Symbian":
        # import e32
        # return e32.drive_list()
# drives=find_drives("Symbian")

m3u_first_line="#EXTM3U"
m3u_info_line="#EXTINF:"
l_info_line=len(m3u_info_line)
def load(file):
    if file == None:
        raise IOError('Nessun file!')
    f = open(file, 'rb')
    text = f.read()
    f.close()
    if text.startswith('\xff\xfe') or text.startswith('\xfe\xff'): #Se � unicode
        text = text.decode('utf16')
    elif text.startswith('\xef\xbb\xbf'): #Se � utf8
        text = text.decode('utf8')
    else:
        for enc in ['ascii','utf8', 'latin1','iso-8859-1']:
            try:
                text = text.decode(enc)#.replace(u"\x00","")
                break
            except UnicodeError:
                pass
        else:
            raise UnicodeError
    return text
def read_playlist(filename,check_path=(0,""),extinf=0):
    '''Legge la playlist m3u, ritornando una lista con tutte le canzoni'''
    if extinf: raise Warning,"Not Implemented"
    temp=[]
    #Qui si pu� fare un temp_info per fare una lista contenente le "info" #EXTINF
    try:
        #f=open(filename,"r")
        linee=(load(filename)).splitlines()
        #f.close()
    except:
        raise "ReadM3UError"
    try:
        linee.remove(m3u_first_line)
    except: pass
    for i in linee:
        if i[:l_info_line]==m3u_info_line: continue
        if not i: continue #Se c'� una linea vuota, non � corretto inserirla nella lista delle canzoni....:)
        else: temp.append(i)
    if check_path[0]:
        temp1=[]
        # for dire in temp:
            # path=os.path.normpath(dire)
            # try:
                # if os.path.isabs(path): pass
                # else:
                    # if os.path.exists(os.path.join(check_path[1],path)):
                        # path=os.path.join(check_path[1],path)
                    # else:
                        # import e32
                        # for i in e32.drive_list():
                            # if os.path.exists(os.path.join(i+u"\\",path)):
                                # path=os.path.join(i+u"\\",path)
                                # break
            # except:
                # pass
            # temp1.append(path)
        for dire in temp:
            path=os.path.normpath(dire).encode('utf8')
            try:
                if os.path.isabs(path) and os.path.exists(path): pass
                else:
                    if os.path.exists(os.path.join(check_path[1].encode('utf8'),path)):
                        path=os.path.join(check_path[1].encode('utf8'),path)
                    else:
                        import e32
                        for i in e32.drive_list():
                            if os.path.exists(os.path.join((i+"\\").encode('utf8'),path)):
                                path=os.path.join((i+"\\").encode('utf8'),path)
                                break
            except:
                pass
            temp1.append(path.decode('utf8'))
        return temp1
    else:
        return temp
 
def extinfo_values(info_line): #Ottiene informazioni dalla line di informazioni della playlist
 #EXTINF:duration (int),Filename.mp3
 if info_line.split(":")[0] != m3u_info_line[:-1]: return None #Ulteriore controllo ;-)
 duration,name=info_line.split(":")[1].split(",")
 duration=int(duration)
 return duration,name
 
def write_playlist(filename,song_list,ext_inf=0,based_on_id3=0,space_between_songs=0):
    '''Scrive una playlist, data una lista di canzoni (opzionale: 1)scrivi #extinfo,'''
    '''2)#Extinfo basato su ID3, 3)Spazio tra le righe della playlist'''
    '''Ritorna un messaggio se correttamente scritti, se errore ritorna l'errore corrispondente'''
    '''File non necessariamente deve essere esistente, ma la/e directory si'''
    if song_list==[] or song_list=="": raise ValueError,"Song list empty"
    if filename==None or filename=="": raise ValueError, "Destination file not specified"
    import codecs
    f=codecs.open (filename,"w",'utf8') #Attenzione! Cancella contenuto attuale!!
    f.write(m3u_first_line) #Scrive la prima linea, standard m3u
    f.write("\r\n")
    if ext_inf==1:
        for i in song_list:
            if based_on_id3:
                raise Warning,"Extinf by id3 not supported now"
            else:
                ext_len=len(os.path.splitext(i)[1])
                name=os.path.split(i)[1][:-ext_len]
                f.write(extinfo_values_pack(0,name)) #duration=0, magari si potrebbe "chiedere" ad audio.Sound.open().duration()...
                f.write("\r\n")
                f.write(i)
                f.write("\r\n")
                if space_between_songs: f.write("\r\n") #Aggiunge uno spazio, + che altro x bellezza se uno lo apre!! Windows Media Player fa cosi...
    else:
        for i in song_list:
            f.write(i)
            f.write("\r\n")
            if space_between_songs: f.write("\r\n") #Aggiunge uno spazio, + che altro x bellezza se uno lo apre!! Windows Media Player fa cosi...
    f.close()
    return 1#"M3U Playlist Salvata Correttamente!"

def extinfo_values_pack(duration,name): #Da durata e nome, si ottiene la riga #EXTINF
  '''Codice x creare una lista di linee #EXTINF:durata,nome'''
  duration=str(duration)
  name=str(name)
  info_line=m3u_info_line+duration+","+name
  return info_line

def info_playlist(filename):
 '''Informazioni su una playlist'''
 try:
  songs=read_playlist(filename)
  len_songs=len(songs)
  size=os.path.getsize(filename)
  return len_songs,size
 except:
  raise "ReadError"
