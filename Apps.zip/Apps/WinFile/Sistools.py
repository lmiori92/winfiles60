'''
Sistools by Memory � 2008-2009
15/01/08
'''

'''
Versione 1.01 (26/02/09)
-Aggiornata la ricerca di informazioni su file .jar (lista manifest); sistemati alcuni bug e supporto per l'unicode
'''

sis_options={1:"(IU)IsUnicode",2:"(ID)IsDistributable",8:"(NC)NOCOMPRESS",10:"(SH)SHUTDOWNAPPS"}

sis_type={0:"SA,SISAPP",1:"SY,SISSYSTEM",
          2:"SO,SISOPTION",3:"SC,SISCONFIG",
          4:"SP,SISPATCH",5:"SU,SISUPGRADE"}

def get_long_be(s):
    """Convert a 4-char value to integer."""
    return (ord(s[0])<<24) | (ord(s[1])<<16) | (ord(s[2])<<8) | ord(s[3])
    
def get_int_2char(s):
    """Convert a 2-char value to integer."""
    return (ord(s[1])<<8) | (ord(s[0]))

def get_inverted_bytes(u):
    '''Funzione per invertire a coppie di 2 l'uid, in quanto i byte dell'uid nel sis'''
    '''sono invertiti, a coppie di due perch� 1 byte sono 8 bit, 2x4bit; 4 bit sono 1 cifra hex'''
    '''L'UID deve essere HEX!!!'''
    s=str(u)
    s1=s[:2] #0x
    s2=s[2:-6]
    s3=s[4:-4]
    s4=s[6:-2]
    s5=s[8:]
    temp=s1+s5+s4+s3+s2 #0xs5s4s3s2
    return temp

def read_sis_file(file):
 '''Informazioni su pacchetti sis (Symbian Installation System)'''
 f=open(file,"rb")
 err="-"
 try:
  f.seek(0) #UID
  uid=hex(get_long_be(f.read(4)))
  uid=get_inverted_bytes(uid)
 except:
  uid=err
 try:
  f.seek(20) #Numero files totali nel SiS
  num_f=f.read(2)
  num_f=str(get_int_2char(num_f))
 except:
  num_f=err
 try:
  f.seek(18) #Numero lingue totali
  num_lang=f.read(2)
  num_lang=str(get_int_2char(num_lang))
 except:
  num_lang=err
 try:
  f.seek(20) #Versione installer
  installer_ver=str(get_long_be(f.read(4)))
 except:
  installer_ver=err
 try:
  f.seek(28) #Drive installazione
  drive=f.read(2).strip("\x00")
 except:
  drive=err
 try:
  f.seek(36) #Opzioni
  options=str(get_int_2char(f.read(2)))
 except:
  options=err
 try:
  f.seek(38) #Tipo installer
  type=str(get_int_2char(f.read(2)))
 except:
  type=err
 try:
  f.seek(40) #Majour version
  max_version=str(get_int_2char(f.read(2)))
 except:
  max_version=err
 try:
  f.seek(42) #Minour version
  min_version=str(get_int_2char(f.read(2)))
 except:
  min_version=err
 try:
  f.seek(44) #Build version
  build_version=str(get_int_2char(f.read(2)))
 except:
  build_version=err
 f.close()
 try:
  sisfile_info={"Files":num_f,
   "Langs":num_lang,
   "Drive":drive,
   # "MaxVer":max_version,
   # "MinVer":min_version,
   # "Build":build_version,
   "Version":("%s.%s.%s"%(max_version,min_version,build_version)),
   "UID":uid,
   "Options":sis_options[int(options)],
   "Type":sis_type[int(type)]}
 except:
  sisfile_info={"Files":num_f,
   "Langs":num_lang,
   "Drive":drive,
   # "MaxVer":max_version,
   # "MinVer":min_version,
   # "Build":build_version,
   "Version":("%s.%s.%s"%(max_version,min_version,build_version)),
   "UID":uid,
   "Options":options,
   "Type":type}
 return sisfile_info

def read_jar_info(file):
    '''Informazioni su file .jar (Java)'''
    import zipfile #I file jar sono degli archivi zip
    temp=[]
    f=zipfile.ZipFile(file)
    manifest=f.read("META-INF/MANIFEST.MF")
    f.close()
  #manifest=manifest.decode("latin-1")
    for enc in ['ascii','utf8','latin1','iso-8859-1']:
        try:
            manifest = manifest.decode(enc)
            break
        except UnicodeError:
            pass
    else:
        raise UnicodeError
    jar_infos=manifest.splitlines()
    for i in jar_infos:
        try:
            temp.append(tuple(i.split(u":")))
        except:
            pass
    return temp
# except: raise RuntimeError,"The file is not a jar file or I-O error"
