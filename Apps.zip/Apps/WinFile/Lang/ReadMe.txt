WinFile Language Directory
-------------------------

In questa cartella vanno collocati i file di traduzione.
In this directory must be placed language files.

Dalla versione 1.05 � stato attivato il sistema di traduzione delle stringhe del programma.
I file di lingua .ini sono i file di lingua non compilati e sono adatti a scopo di prove (mentre si sta traducendo): tra le cose pi� importanti viene effettuato un test di sintassi e di correttezza. Ogni errore viene scritto nel debug.
I file di lingua .lng sono, invece, i file di lingua compilati: vengono caricati molto pi� velocemente e non viene effettuato nessun controllo (non � necessario).

From version 1.05 it's possible to translate strings of the software.
The language files .ini are the language files wich aren't compilated and thus they're good during translation to check if they're correct: in this mode there is a syntax check. Every error is printed in the debug log.
The language files .lng are the language files wich are compilated: they are loaded faster and they aren't checked.

WinFile Symbian OS S60 filemanager
(C) Memory 2008-2010