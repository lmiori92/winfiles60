#!/usr/bin/env python
# -*- coding: latin-1 -*-

#
# PLAYER - CORE module for WinFile & Others by MEMORY �2007-2010
# Module to control the audio file, playing, rewieving , control the volume ecc....
# Modulo per controllare il file audio, come volume , play-pausa , indietro veloce ecc..
#

#Version 1.2

#1.1 (31.10.08):
#    -Cleaned code
#    -Seeking control: the rew() or ff() function returns when it's already seeking, to prevent crashes and/or other errors
#    -Seek is locked when the audio is paused (solves a bug)
#    -Seek is impossibile out of the file lenght
#1.2 (.04.10):
#   -Code cleanup
#   -Fixed rew / ff controls
#1.3 (24.10.10):
#   -added coding definition
#   -comment cleaned
#   -optimized import of audio lib

import audio
from audio import ENotReady, EOpen, EPlaying, ERecording

# ENotReady
# The Sound object has been constructed but no audio file is open.
# EOpen
# An audio file is open but no playing or recording operation is in progress.
# EPlaying
# An audio file is playing.
# ERecording
# An audio file is being recorded.
#audio.KMdaRepeatForever -> forever loop

class player:
    def __init__(s,audiofile,volume=3,position=0,play_at_init=0,repeat=0,callback=None):
        s.audio_object=audio.Sound()
        s.audio_file=audiofile
        s.volume=volume
        s.pos=position
        s.callback=callback
        s.in_pause=0
        s.seeking=0
        s.repeat=repeat
        s.max_vol=10
        s.min_vol=0
        s.sec_rew_ff=5 #seconds
    def play_audio(s,request_new_audio=1):
        if request_new_audio:
            try:
                s.sound_opened.stop()
                s.sound_opened.close()
            except:
                pass
            s.sound_opened=s.audio_object.open(s.audio_file)
        s.sound_opened.set_volume(s.volume)
        s.sound_opened.set_position(s.pos)
        s.pos=0 #Reset audio position to 0, avoiding playing not from beginning
        if s.callback: s.sound_opened.play(times=s.repeat,interval=0,callback=s.callback)
        else: s.sound_opened.play(times=s.repeat,interval=0)
    def getstate(s):
        state=s.sound_opened.state()
        duration=0
        current_position=0
        if state==EPlaying:
            duration=s.sound_opened.duration()
            current_position=s.sound_opened.current_position()
        elif state==EOpen:
            duration=s.sound_opened.duration()
            current_position=s.pos
        return state,s.volume,duration,current_position
    def pause(s):
        if s.sound_opened.state()==EPlaying and s.in_pause==0:
            s.pos=s.sound_opened.current_position()
            s.sound_opened.stop()
            s.in_pause=1
        elif s.sound_opened.state()==EOpen and s.in_pause==1:
            s.in_pause=0
            s.play_audio(0)
        else:
            s.play_audio(1)
    def stop(s):
        s.sound_opened.stop()
    def unload_all(s):
        s.stop()
        s.sound_opened.close()
    def rew(s):
        if s.seeking or s.in_pause: return
        s.seeking=1
        try:
            posatt=s.sound_opened.current_position()
            s.stop()
            to=posatt-(s.sec_rew_ff*1000000)
            if not (to<0):
                s.pos=to
            s.play_audio(0)
        except:
            s.pos=0
        s.seeking=0
    def ff(s):
        if s.seeking or s.in_pause: return
        s.seeking=1
        try:
            dur=s.sound_opened.duration()
            posatt=s.sound_opened.current_position()
            s.stop()
            to=posatt+(s.sec_rew_ff*1000000)
            if not (to>dur):
                s.pos=to
            s.play_audio(0)
        except:
            s.pos=0
        s.seeking=0
    def vol_up(s):
        s.volume+=1
        #Volume check
        if s.volume>s.max_vol:
            s.volume=s.max_vol  #maximum volume
        s.sound_opened.set_volume(s.volume)
    def vol_down(s):
        s.volume-=1
        #Volume check
        if s.volume<s.min_vol:
            s.volume=s.min_vol  #minimum volume
        s.sound_opened.set_volume(s.volume)
#FINE