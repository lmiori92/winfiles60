#OggTag reader by Dokkis
#Alcuni bug risolti da Memory
#Codice ripulito e tolte alcune funzioni inutili allo scopo di WinFile (Memory)
debug=0
def endtag(ch):
    if(ch==""):
        return 0    
    try:
        if(ord(ch)>30):
            return 0
        else:
            return 1
    except:
        return 1

def readOggTag(filename):
    f = open(filename,'r')
    f.seek(176)
    contblank=0
    title   = "-"
    artist  = "-"
    album   = "-"
    genere  =  "-"
    year= "-"
    comment="-"
    track="-"
    ch=""
    while 1:
        temp=""
        while(endtag(ch)!=1):
            temp+=ch
            ch=f.read(1)
        if(temp==""):
            if(contblank>=5):
                break
            contblank+=1
            ch=f.read(1)
        else:
            try:
                if(temp.lower().find("title=")==0):
                    title=unicode(temp[6:],'utf-8')
                elif(temp.lower().find("album=")==0):# Non va sulla mia canzone
                    album=unicode(temp[6:],'utf-8')
                elif(temp.lower().find("artist=")==0):# Non va sulla mia canzone
                    artist=unicode(temp[7:],'utf-8')
                elif(temp.lower().find("date=")==0):
                    year=unicode(temp[5:],'utf-8')
                elif(temp.lower().find("genre=")==0):
                    genere=unicode(temp[6:],'utf-8')
                elif(temp.lower().find("comment=")==0):
                    comment=unicode(temp[8:],'utf-8')
                elif(temp.lower().find("tracknumber=")==0):
                    track=unicode(temp[12:],'utf-8')
                else: pass
            except:
                if debug: print "OGG ENCODE ERROR"
        tch=ord(f.read(1))
        while(tch==0):
            read=f.read(1)
            tch=ord(read)
            ch=read
    f.close()
    return {'Titolo':title, 'Commento':comment,'Traccia':track,'Anno': year,'Artista':artist, 'Album':album, 'Genere':genere}