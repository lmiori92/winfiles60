#!/usr/bin/env python
# -*- coding: latin-1 -*-

import struct,sys#,appuifw

#Mp3 ID3 Tools by Memory � 2007-2008
#Versione 0.1 (29.11.07):
#    -Versione iniziale.
#Versione 0.2 (6.02.08) ->Bug corretti:
#   -Ritorno di dizionario non unicode se tag non presenti;
#   -Tolto l'uso di encode nella funzione updateID3
#Versione 0.3 (29.02.08)
#   -Aggiunta funzione "Rimuovi tag"
#Versione 0.4 (7.09.08)
#   -Tolto completamente l'uso di UI all'interno di questa libreria, pu� essere anche cosi usato in un 'server'
#Versione 0.5 (29.10.08)
#   -Codice ripulito
#   -Eccezzione gestita in caso che il file sia di dimensione inferiore di 128 byte (File invalido)
#   -Scrittura migliorata: se il numero traccia non � presente, scrive i tag nella versione 1.0 e non 1.1
#   -Migliorata la funzione rimuovi tag
#   -I tag rimossi con questa libreria, non vengono letti proprio
#Versione 0.6 (21.12.08)
#   -Corretto bug: se esiste nel commento anche il numero della traccia, lo evita e taglia la parte inutile
#Versione 0.7 (24.10.10)
#   -aggiunta definizione codifica


__all__=["getID3","updateID3","remove_all_tags"]

generi = ('Blues','Classic Rock','Country','Dance','Disco','Funk','Grunge','Hip-Hop','Jazz','Metal','New Age',
        'Oldies','Other','Pop','R&B','Rap','Reggae','Rock','Techno','Industrial','Alternative','Ska','Death Metal',
        'Pranks','Soundtrack','Euro-Techno','Ambient','Trip-Hop','Vocal','Jazz+Funk','Fusion','Trance','Classical',
        'Instrumental','Acid','House','Game','Sound Clip','Gospel','Noise','Alternative Rock','Bass','Soul',
        'Punk','Space','Meditative','Instrumental Pop','Instrumental Rock','Ethnic','Gothic','Darkwave','Techno-Industrial',
        'Electronic','Pop-Folk','Eurodance','Dream','Southern Rock','Comedy','Cult','Gangsta','Top 40','Christian Rap',
        'Pop/Funk','Jungle','Native US','Cabaret','New Wave','Psychadelic','Rave','Showtunes','Trailer','Lo-Fi','Tribal',
        'Acid Punk','Acid Jazz','Polka','Retro','Musical','Rock & Roll','Hard Rock','Folk','Folk-Rock','National Folk','Swing',
        'Fast Fusion','Bebob','Latin','Revival','Celtic','Bluegrass','Avantgarde','Gothic Rock','Progressive Rock',
        'Psychedelic Rock','Symphonic Rock','Slow Rock','Big Band','Chorus','Easy Listening','Acoustic','Humour','Speech',
        'Chanson','Opera','Chamber Music','Sonata','Symphony','Booty Bass','Primus','Porn Groove','Satire','Slow Jam',
        'Club','Tango','Samba','Folklore','Ballad','Power Ballad','Rhytmic Soul','Freestyle','Duet','Punk Rock','Drum Solo',
        'Acapella','Euro-House','Dance Hall','Goa','Drum & Bass','Club-House','Hardcore','Terror','Indie','BritPop',
        'Negerpunk','Polsk Punk','Beat','Christian Gangsta','Heavy Metal','Black Metal','Crossover','Contemporary C',
        'Christian Rock','Merengue','Salsa','Trash Metal','Anime','JPop','SynthPop'
    )

def getID3(filename):
    title   = "-"
    artist  = "-"
    album   = "-"
    year    = "-"
    comment = "-"
    genere  = "-"
    fp = open(filename, 'r')
    try:
        fp.seek(-128, 2)
    except:
        fp.close()
        raise RuntimeError, "Filesize < 128!"
    try:
        if fp.read(3)!='TAG':     # TAG iniziale, se non essiste, non esistono i tag....
            return None#{'Titolo':u"-", 'Artista':u"-", 'Album':u"-", 'Anno':u"-",'Commento':u"-",'Genere':u"-"}
        elif fp.read(125)==("\x00"*125):
            return None
        else:
            fp.seek(-125, 2)
            title   = unicode(fp.read(30).replace("\00",""),'latin-1')#.encode("utf8","ignore") #legge e sostituisce i caratteri vuoti con uno spazio 
            artist  = unicode(fp.read(30).replace("\00",""),'latin-1')#.encode("utf8","ignore")
            album   = unicode(fp.read(30).replace("\00",""),'latin-1')#.encode("utf8","ignore")
            year    = unicode(fp.read(4).replace("\00",""),'latin-1')#.encode("utf8","ignore"  )
            comment = unicode(fp.read(28).replace("\00",""),'latin-1')#.encode("utf8","ignore")
            track = fp.read(2)
            #if comment[-2]==u"\x00" and comment[-1]!=u"\x00": comment=comment[:-2]
            genere_number = fp.read(1)
    except:
        fp.close()
        raise ValueError,'Tag error!'
    try:
        genere=unicode(generi[int(ord(genere_number))])
    except:
        pass
    fp.close()
    return {'Titolo':title, 'Artista':artist, 'Album':album, 'Anno':year,'Commento':comment,'Genere':genere}

def updateID3(filename="",title="",artist="",album="",year="",comment="",track=None,genre=255):  #Funzione che aggiorna le informazioni id3 tag
    if year: y = str(year)
    else: y = ''
    if genre>148: genre=255
    #Prepara i tag da scrivere successivamente
    if track:
        tag = struct.pack('3s30s30s30s4s28sBBB','TAG', \
            title, \
            artist, \
            album, \
            y, \
            comment, \
            0, \
            int(track),
            genre)
    else:
        tag = struct.pack('3s30s30s30s4s30sB','TAG', \
            title, \
            artist, \
            album, \
            y, \
            comment,
            genre)
    if filename=="":
        print "Test mode"
        print 'ID3v1.1 length = ' + str(len(tag))
        print tag
        return
    f = open(filename, 'r+b')  #Apri il file r+ in modalit� binaria (Attenzione! Su file non esistenti restituisce errore!)
    try:
        f.seek(-128, 2)
    except:
        f.close()
        raise RuntimeError, "Filesize < 128!"
    #Bisogna vedere se ci sono gi� i tag, altrimenti li sovrascrive
    if('TAG' == f.read(3)): f.seek(-128,2)
    else: f.seek(0,2)
    f.write(tag)
    f.close

def remove_all_tags(filename):
    f = open(filename, 'r+b')  #Apri il file r+ in modalit� binaria (Attenzione! Su file non esistenti restituisce errore!)
    try:
        f.seek(-128, 2)
    except:
        f.close()
        raise RuntimeError, "Filesize < 128!"
    if('TAG' == f.read(3)):
        f.seek(-128,2)
        f.write('TAG') #Sostituisce i tag con 128 byte nulli, non considerati comunque dal decoder mp3
        f.write('\x00'*125)
        f.close()
    else:
        f.close()
