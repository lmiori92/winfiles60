WinFile Data Directory
-------------------------

Questa cartella contiene i file di impostazione del programma. Il formato, dalla versione 1.0, � cambiato.
Il formato � ora binario, quindi pi� stabile e pi� facile da gestire nel programma.

settings.dat->Impostazioni generali del programma, dal nome dell'etichetta, al volume del player, al testo di ricerca...
theme.dat->Contiene i colori del tema in uso, eventualmente personalizzati dalla tavolozza.
session.bin->Contiene i dati dell'ultima sessione se � attiva l'impostazione "Salva sessione" (directory e file selezionato)

N.B: dalla versione 1.03 in questa cartella potrebbero esserci anche altri file di configurazione (per i plugin). Ad esempio se si utilizza il plugin per
aprire un archivio zip, verr� creato alla modifica di una impostazione interna al plugin un file nominato zip_plugin.dat.

WinFile Symbian OS S60 filemanager
�2008-2010 Memory