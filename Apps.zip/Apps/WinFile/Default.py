#WinFile Loader
#Symbian UID 0x0x06dfae12 (Official from Symbian)
import WinFile